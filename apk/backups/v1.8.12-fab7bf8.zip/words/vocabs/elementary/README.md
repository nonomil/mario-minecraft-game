# 小学词库

来源：`d:\WorkPlace\Html\单词库\vocabularies\stage\`

包含：
- `stage_elementary_lower.js`（manifest id: `elementary.lower`）
- `stage_elementary_upper.js`（manifest id: `elementary.upper`）

字段说明（原始格式）：
- `word`：英文
- `chinese`：中文
- `imageURLs`：图片列表（URL）

