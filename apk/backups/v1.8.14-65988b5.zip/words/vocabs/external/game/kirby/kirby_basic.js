// Kirby Basic Vocabulary - æç®çï¼ä½¿ç¨ Twemoji CDN SVG å¾æ ä½ä¸ºå ä½ï¼
// è¯´æï¼éç¨éç¨è¡¨æ Emojiï¼é¿åçæä¸è·¨åé®é¢ãURL æ ¼å¼ç¤ºä¾ï¼https://twemoji.maxcdn.com/v/latest/svg/2b50.svg

const KIRBY_BASIC = [
];

// å¯¼åºï¼å¼å®¹æµè§å¨ä¸ Nodeï¼
if (typeof module !== 'undefined' && module.exports) {
  module.exports = KIRBY_BASIC;
} else if (typeof window !== 'undefined') {
  window.KIRBY_BASIC = KIRBY_BASIC;
}
  { word: "Kirby", chinese: "å¡æ¯", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f497.svg"] },
  { word: "King Dedede", chinese: "å¸å¸å¸å¤§ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f451.svg"] },
  { word: "Meta Knight", chinese: "é­å¡éªå£«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2694.svg"] },
  { word: "Waddle Dee", chinese: "ç¦è±è¿ª", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f424.svg"] },
  { word: "Warp Star", chinese: "é£è¡ææ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f320.svg"] },
  { word: "Maxim Tomato", chinese: "æéçªè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f345.svg"] },
  { word: "Sword Ability", chinese: "åè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f5e1.svg"] },
  { word: "Fire Ability", chinese: "ç«ç°è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f525.svg"] },
  { word: "Ice Ability", chinese: "å°è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2744.svg"] },
  { word: "Hammer Ability", chinese: "é¤å­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f528.svg"] },
  { word: "Parasol Ability", chinese: "é¨ä¼è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2602.svg"] },
  { word: "Star Power", chinese: "æä¹åé", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2728.svg"] },
  { word: "Bandana Waddle Dee", chinese: "å¤´å·¾ç¦è±è¿ª", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f94b.svg"] },
  { word: "Gooey", chinese: "å¤ä¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f5.svg"] },
  { word: "Magolor", chinese: "çææ´å°", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3f7.svg"] },
  { word: "Taranza", chinese: "å¡å°è¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f577.svg"] },
  { word: "Susie", chinese: "èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4bb.svg"] },
  { word: "Galacta Knight", chinese: "é¶æ²³éªå£«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2728.svg"] },
  { word: "Dark Meta Knight", chinese: "é»æé­å¡éªå£«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f5a4.svg"] },
  { word: "Marx", chinese: "é©¬åæ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f985.svg"] },
  { word: "Adeleine", chinese: "é¿é»ç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a8.svg"] },
  { word: "Ribbon", chinese: "ä¸å¸¦å¦ç²¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f380.svg"] },
  { word: "Elfilin", chinese: "è¾è²ç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f43f.svg"] },
  { word: "Fecto Forgo", chinese: "è´¹åæÂ·ç¦å°æ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f47e.svg"] },
  { word: "Nightmare", chinese: "æ¢¦é­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f319.svg"] },
  { word: "Daroach", chinese: "è¾¾æ´å¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f400.svg"] },
  { word: "Chef Kawasaki", chinese: "å·å´å¨å¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f373.svg"] },
  { word: "Whispy Woods", chinese: "å¼å¦å¼å¦æ /å¤§æ ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f333.svg"] },
  { word: "Kracko", chinese: "åæç§", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26c5.svg"] },
  { word: "Cutter Ability", chinese: "åå²è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2702.svg"] },
  { word: "Beam Ability", chinese: "åæè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a1.svg"] },
  { word: "Bomb Ability", chinese: "ç¸å¼¹è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a3.svg"] },
  { word: "Stone Ability", chinese: "ç³å¤´è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26f0.svg"] },
  { word: "Wheel Ability", chinese: "è½¦è½®è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6de.svg"] },
  { word: "Wing Ability", chinese: "é£ç¿¼è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f985.svg"] },
  { word: "Jet Ability", chinese: "å·å°è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f680.svg"] },
  { word: "Yo-Yo Ability", chinese: "æ æ çè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg"] },
  { word: "Plasma Ability", chinese: "ç­ç¦»å­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26a1.svg"] },
  { word: "Mirror Ability", chinese: "éå­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9ff.svg"] },
  { word: "Ninja Ability", chinese: "å¿èè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f977.svg"] },
  { word: "Fighter Ability", chinese: "æ ¼æè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f94a.svg"] },
  { word: "Suplex Ability", chinese: "èæè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f94a.svg"] },
  { word: "Throw Ability", chinese: "ææ·è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3b1.svg"] },
  { word: "Sleep Ability", chinese: "ç¡è§è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6cc.svg"] },
  { word: "Paint Ability", chinese: "ç»ç»è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f58c.svg"] },
  { word: "Doctor Ability", chinese: "å»çè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2695.svg"] },
  { word: "Poison Ability", chinese: "æ¯æ¶²è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2620.svg"] },
  { word: "Spider Ability", chinese: "èèè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f577.svg"] },
  { word: "ESP Ability", chinese: "è¶è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9e0.svg"] },
  { word: "Beetle Ability", chinese: "ç²è«è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41e.svg"] },
  { word: "Bell Ability", chinese: "ééè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f514.svg"] },
  { word: "Circus Ability", chinese: "é©¬æè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3aa.svg"] },
  { word: "Archer Ability", chinese: "å¼ç®­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3f9.svg"] },
  { word: "Sand Ability", chinese: "æ²å­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3dc.svg"] },
  { word: "Mecha Ability", chinese: "æºç²è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f916.svg"] },
  { word: "Water Ability", chinese: "æ°´æµè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a7.svg"] },
  { word: "Leaf Ability", chinese: "æ å¶è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f343.svg"] },
  { word: "Spear Ability", chinese: "é¿çè½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2694.svg"] },
  { word: "Whip Ability", chinese: "é­å­è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f6.svg"] },
  { word: "Snow Ability", chinese: "éªè±è½å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2744.svg"] },
  { word: "Star Rod", chinese: "æä¹æ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2728.svg"] },
  { word: "Invincible Candy", chinese: "æ æç³æ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f36c.svg"] },
  { word: "Food", chinese: "é£ç©", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f35e.svg"] },
  { word: "Copy Essence", chinese: "å¤å¶ä¹æº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f52e.svg"] },
  { word: "Halberd", chinese: "æè°åå°ä¼¯å¾·", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6f3.svg"] },
  { word: "Star Allies", chinese: "æä¹çå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },
  { word: "Dream Land", chinese: "æ¢¦å¹»ä¹å½", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3f0.svg"] }