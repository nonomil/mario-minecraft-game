// PVZ Basic Vocabulary - æç®çï¼ä½¿ç¨ Twemoji CDN SVG å¾æ ï¼ç¨³å®ä¸è·¨å¹³å°ï¼
// è¯´æï¼ä¸ºé¿åçæä¸è·¨åé®é¢ï¼ä½¿ç¨éç¨è¡¨æ Emoji ç Twemoji SVG ä½ä¸ºå¾æ å ä½
// é¾æ¥æ ¼å¼ç¤ºä¾ï¼https://twemoji.maxcdn.com/v/latest/svg/1f33b.svg ï¼ð»ï¼

const PVZ_BASIC = [
];

// å¯¼åºï¼å¼å®¹æµè§å¨ä¸ Nodeï¼
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PVZ_BASIC;
} else if (typeof window !== 'undefined') {
  window.PVZ_BASIC = PVZ_BASIC;
}
  {
    word: "Sunflower",
    chinese: "åæ¥èµ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33b.svg"], // ð»
  },
  {
    word: "Peashooter",
    chinese: "è±è±å°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±ï¼å¹¼èä»£æï¼
  },
  {
    word: "Wall-nut",
    chinese: "åæå¢",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f330.svg"], // ð°ï¼æ¿æ è¿ä¼¼ä»£æï¼
  },
  {
    word: "Cherry Bomb",
    chinese: "æ¨±æ¡ç¸å¼¹",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f352.svg"], // ð
  },
  {
    word: "Potato Mine",
    chinese: "åè±é·",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f954.svg"], // ð¥
  },
  {
    word: "Snow Pea",
    chinese: "å¯å°å°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2744.svg"], // âï¸ï¼éªè±ä»£æï¼
  },
  {
    word: "Ice-shroom",
    chinese: "å¯å°è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9ca.svg"], // ð§ï¼å°åï¼
  },
  {
    word: "Jalapeno",
    chinese: "ç«çè¾£æ¤",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f336.svg"], // ð¶ï¸
  },
  {
    word: "Squash",
    chinese: "å­çï¼æ£ä¹±èåä¹æ¿ä»£å¾å½¢ï¼",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f383.svg"], // ðï¼åçè¿ä¼¼ä»£æï¼
  },
  {
    word: "Torchwood",
    chinese: "ç«ç¬æ æ¡©",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f525.svg"], // ð¥
  },
  {
    word: "Lily Pad",
    chinese: "ç¡è²å¶",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f30a.svg"], // ðï¼æ°´é¢ä»£æï¼
  },
  {
    word: "Cactus",
    chinese: "ä»äººæ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f335.svg"], // ðµ
  },
  // å¤§è§æ¨¡æ©åè³100æ¡ï¼+78ï¼
  {
    word: "Repeater",
    chinese: "ååå°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Threepeater",
    chinese: "ä¸çº¿å°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Split Pea",
    chinese: "è£èå°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Gatling Pea",
    chinese: "æºæªå°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Twin Sunflower",
    chinese: "åå­åæ¥èµ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33b.svg"], // ð»
  },
  {
    word: "Tall-nut",
    chinese: "é«åæ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f330.svg"], // ð°
  },
  {
    word: "Pumpkin",
    chinese: "åçå¤´",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f383.svg"], // ð
  },
  {
    word: "Spikeweed",
    chinese: "å°åº",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f335.svg"], // ðµ
  },
  {
    word: "Spikerock",
    chinese: "é¢å°åº",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f335.svg"], // ðµ
  },
  {
    word: "Chomper",
    chinese: "å¤§å´è±",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33a.svg"], // ðº
  },
  {
    word: "Blover",
    chinese: "ä¸å¶è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f340.svg"], // ð
  },
  {
    word: "Plantern",
    chinese: "è·¯ç¯è±",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a1.svg"], // ð¡
  },
  {
    word: "Starfruit",
    chinese: "æ¨æ¡",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"], // â­
  },
  {
    word: "Magnet-shroom",
    chinese: "ç£åè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f2.svg"], // ð§²
  },
  {
    word: "Doom-shroom",
    chinese: "æ¯ç­è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a5.svg"], // ð¥
  },
  {
    word: "Coffee Bean",
    chinese: "åå¡è±",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2615.svg"], // â
  },
  {
    word: "Umbrella Leaf",
    chinese: "å¶å­ä¿æ¤ä¼",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2602.svg"], // âï¸
  },
  {
    word: "Marigold",
    chinese: "éçè±",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33c.svg"], // ð¼
  },
  {
    word: "Kernel-pult",
    chinese: "çç±³ææ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33d.svg"], // ð½
  },
  {
    word: "Cabbage-pult",
    chinese: "å·å¿èææ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f96c.svg"], // ð¥¬
  },
  {
    word: "Melon-pult",
    chinese: "è¥¿çææ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f349.svg"], // ð
  },
  {
    word: "Winter Melon",
    chinese: "å°ç",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9ca.svg"], // ð§
  },
  {
    word: "Buckethead Zombie",
    chinese: "éæ¡¶åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1faa3.svg"], // ðª£
  },
  {
    word: "Conehead Zombie",
    chinese: "è·¯éåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6a7.svg"], // ð§
  },
  {
    word: "Pole Vaulting Zombie",
    chinese: "ææåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f93e.svg"], // ð¤¾
  },
  {
    word: "Football Zombie",
    chinese: "æ©æ¦çåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3c8.svg"], // ð
  },
  {
    word: "Dancing Zombie",
    chinese: "èçåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f57a.svg"], // ðº
  },
  {
    word: "Backup Dancer",
    chinese: "ä¼´èåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f483.svg"], // ð
  },
  {
    word: "Ducky Tube Zombie",
    chinese: "é¸­å­æçååµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f986.svg"], // ð¦
  },
  {
    word: "Snorkel Zombie",
    chinese: "æ½æ°´åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f93f.svg"], // ð¤¿
  },
  {
    word: "Zomboni",
    chinese: "å°è½¦åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9ca.svg"], // ð§
  },
  {
    word: "Zombie Bobsled Team",
    chinese: "éªæ©è½¦åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6f7.svg"], // ð·
  },
  {
    word: "Dolphin Rider Zombie",
    chinese: "æµ·è±éªå£«åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f42c.svg"], // ð¬
  },
  {
    word: "Jack-in-the-Box Zombie",
    chinese: "å°ä¸åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f921.svg"], // ð¤¡
  },
  {
    word: "Balloon Zombie",
    chinese: "æ°çåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f388.svg"], // ð
  },
  {
    word: "Digger Zombie",
    chinese: "ç¿å·¥åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26cf.svg"], // âï¸
  },
  {
    word: "Pogo Zombie",
    chinese: "è·³è·³åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f93e.svg"], // ð¤¾
  },
  {
    word: "Ladder Zombie",
    chinese: "æ¢¯å­åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa9c.svg"], // ðª
  },
  {
    word: "Catapult Zombie",
    chinese: "æç¯®è½¦åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3c0.svg"], // ð
  },
  {
    word: "Gargantuar",
    chinese: "å·¨äººåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9cc.svg"], // ð§
  },
  {
    word: "Imp",
    chinese: "å°é¬¼åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f47f.svg"], // ð¿
  },
  {
    word: "Dr. Zomboss",
    chinese: "åµçåå£«",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d1-200d-1f52c.svg"], // ð§âð¬
  },
  {
    word: "Zombot",
    chinese: "åµå°¸æºå¨äºº",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f916.svg"], // ð¤
  },
  {
    word: "Lawn Mower",
    chinese: "å²èæº",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f69c.svg"], // ð
  },
  {
    word: "Pool Cleaner",
    chinese: "æ°´æ± æ¸æ´è½¦",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f30a.svg"], // ð
  },
  {
    word: "Roof Cleaner",
    chinese: "å±é¡¶æ¸æ´è½¦",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3e0.svg"], // ð 
  },
  {
    word: "Watering Can",
    chinese: "æ´æ°´å£¶",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a7.svg"], // ð§
  },
  {
    word: "Fertilizer",
    chinese: "åè¥",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a9.svg"], // ð©
  },
  {
    word: "Bug Spray",
    chinese: "æè«å",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41b.svg"], // ð
  },
  {
    word: "Phonograph",
    chinese: "çå£°æº",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3b5.svg"], // ðµ
  },
  {
    word: "Gloom-shroom",
    chinese: "å¿§éè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"], // ð
  },
  {
    word: "Cattail",
    chinese: "é¦è²",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33f.svg"], // ð¿
  },
  {
    word: "Tangle Kelp",
    chinese: "ç¼ ç»æµ·è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33f.svg"], // ð¿
  },
  {
    word: "Sea-shroom",
    chinese: "æµ·èè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"], // ð
  },
  {
    word: "Puff-shroom",
    chinese: "å°å·è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"], // ð
  },
  {
    word: "Sun-shroom",
    chinese: "é³åè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2600.svg"], // âï¸
  },
  {
    word: "Fume-shroom",
    chinese: "å¤§å·è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f32b.svg"], // ð«ï¸
  },
  {
    word: "Hypno-shroom",
    chinese: "é­æè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f60d.svg"], // ð
  },
  {
    word: "Scaredy-shroom",
    chinese: "èå°è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f628.svg"], // ð¨
  },
  {
    word: "Grave Buster",
    chinese: "å¢ç¢åå¬è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26b0.svg"], // â°ï¸
  },
  {
    word: "Imitater",
    chinese: "æ¨¡ä»¿è",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3ad.svg"], // ð­
  },
  {
    word: "Explode-o-nut",
    chinese: "çç¸åæ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a5.svg"], // ð¥
  },
  {
    word: "Giant Wall-nut",
    chinese: "å·¨å¤§åæ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f330.svg"], // ð°
  },
  {
    word: "Sprout",
    chinese: "è±è½",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Reverse Repeater",
    chinese: "ååååå°æ",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f331.svg"], // ð±
  },
  {
    word: "Aqua Shroom",
    chinese: "æ°´çè",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f30a.svg"], // ð
  },
  {
    word: "Zombie Yeti",
    chinese: "éªäººåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2744.svg"], // âï¸
  },
  {
    word: "Bungee Zombie",
    chinese: "è¹¦æåµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f93f.svg"], // ð¤¿
  },
  {
    word: "Target Zombie",
    chinese: "é¶å­åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3af.svg"], // ð¯
  },
  {
    word: "Newspaper Zombie",
    chinese: "è¯»æ¥åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4f0.svg"], // ð°
  },
  {
    word: "Screen Door Zombie",
    chinese: "éæ é¨åµå°¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6aa.svg"], // ðª
  },
  {
    word: "Coin",
    chinese: "éå¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg"], // ðª
  },
  {
    word: "Silver Coin",
    chinese: "é¶å¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg"], // ðª
  },
  {
    word: "Gold Coin",
    chinese: "éå¸",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg"], // ðª
  },
  {
    word: "Diamond",
    chinese: "é»ç³",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f48e.svg"], // ð
  },
  {
    word: "Chocolate",
    chinese: "å·§åå",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f36b.svg"], // ð«
  },
  {
    word: "Present",
    chinese: "ç¤¼ç©",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f381.svg"], // ð
  },
  {
    word: "Trophy",
    chinese: "å¥æ¯",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3c6.svg"], // ð
  },
  {
    word: "Bacon",
    chinese: "å¹æ ¹",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f953.svg"], // ð¥
  },
  {
    word: "Taco",
    chinese: "çç±³é¥¼",
    imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f32e.svg"], // ð®
  }