# Minecraft 词库

来源：`d:\WorkPlace\Html\单词库\vocabularies\minecraft\`

包含：
- `minecraft_basic.js`（manifest id: `minecraft.basic`）

字段说明（原始格式）：
- `word`：英文（可能包含大写）
- `chinese`：中文
- `imageURLs`：图片列表（URL，部分是 minecraft.wiki 的 File 页面）

