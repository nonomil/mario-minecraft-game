// Pokemon All Generations - å®å¯æ¢¦å¨ä¸ä»£è¯æ±åº
// åå«å®å¯æ¢¦ç³»åä¸­ææä¸ä»£çå®å¯æ¢¦ï¼åºäºå®æ¹è¯åæ åå
const POKEMON_ALL_GENERATIONS = [
  // === ç¬¬ä¸ä¸ä»£ (å³é½å°åº) ===
  {
    "word": "Bulbasaur",
    "standardized": "Bulbasaur",
    "chinese": "妙蛙种子",
    "phonetic": "/ˈbʌlbəsɔːr/",
    "phrase": "Bulbasaur the grass Pokemon",
    "phraseTranslation": "草宝可梦妙蛙种子",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Bulbasaur.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Ivysaur",
    "standardized": "Ivysaur",
    "chinese": "妙蛙草",
    "phonetic": "/ˈaɪvisɔːr/",
    "phrase": "Ivysaur the grass Pokemon",
    "phraseTranslation": "草宝可梦妙蛙草",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Ivysaur.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Charmander",
    "standardized": "Charmander",
    "chinese": "小火龙",
    "phonetic": "/ˈtʃɑːrmændər/",
    "phrase": "Charmander the fire Pokemon",
    "phraseTranslation": "火宝可梦小火龙",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "orange_color",
    "type": "Fire",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Charmander.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Charmeleon",
    "standardized": "Charmeleon",
    "chinese": "火恐龙",
    "phonetic": "/ˈtʃɑːrməliən/",
    "phrase": "Charmeleon the fire Pokemon",
    "phraseTranslation": "火宝可梦火恐龙",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "orange_color",
    "type": "Fire",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Charmeleon.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Squirtle",
    "standardized": "Squirtle",
    "chinese": "杰尼龟",
    "phonetic": "/ˈskwɜːrtəl/",
    "phrase": "Squirtle the water Pokemon",
    "phraseTranslation": "水宝可梦杰尼龟",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Squirtle.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Wartortle",
    "standardized": "Wartortle",
    "chinese": "卡咪龟",
    "phonetic": "/ˈwɔːrtɔːrtəl/",
    "phrase": "Wartortle the water Pokemon",
    "phraseTranslation": "水宝可梦卡咪龟",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Wartortle.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Caterpie",
    "standardized": "Caterpie",
    "chinese": "绿毛虫",
    "phonetic": "/ˈkætərpi/",
    "phrase": "Caterpie the bug Pokemon",
    "phraseTranslation": "虫宝可梦绿毛虫",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Caterpie.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f431.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Metapod",
    "standardized": "Metapod",
    "chinese": "铁甲蛹",
    "phonetic": "/ˈmetəpɑd/",
    "phrase": "Metapod the bug Pokemon",
    "phraseTranslation": "虫宝可梦铁甲蛹",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Metapod.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Butterfree",
    "standardized": "Butterfree",
    "chinese": "巴大蝶",
    "phonetic": "/ˈbʌtərfri/",
    "phrase": "Butterfree the bug Pokemon",
    "phraseTranslation": "虫宝可梦巴大蝶",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "white_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Butterfree.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Weedle",
    "standardized": "Weedle",
    "chinese": "独角虫",
    "phonetic": "/ˈwiːdəl/",
    "phrase": "Weedle the bug Pokemon",
    "phraseTranslation": "虫宝可梦独角虫",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Weedle.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Kakuna",
    "standardized": "Kakuna",
    "chinese": "铁壳蛹",
    "phonetic": "/kəˈkuːnə/",
    "phrase": "Kakuna the bug Pokemon",
    "phraseTranslation": "虫宝可梦铁壳蛹",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Kakuna.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Beedrill",
    "standardized": "Beedrill",
    "chinese": "大针蜂",
    "phonetic": "/ˈbiːdrɪl/",
    "phrase": "Beedrill the bug Pokemon",
    "phraseTranslation": "虫宝可梦大针蜂",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£è«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Bug",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Beedrill.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Pidgey",
    "standardized": "Pidgey",
    "chinese": "波波",
    "phonetic": "/ˈpɪdʒi/",
    "phrase": "Pidgey the bird Pokemon",
    "phraseTranslation": "鸟宝可梦波波",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£é£è¡å±æ§å®å¯æ¢¦",
    "special_features": "brown_color",
    "type": "Flying",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Pidgey.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Pidgeotto",
    "standardized": "Pidgeotto",
    "chinese": "比比鸟",
    "phonetic": "/ˈpɪdʒiˌoʊtoʊ/",
    "phrase": "Pidgeotto the bird Pokemon",
    "phraseTranslation": "鸟宝可梦比比鸟",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£é£è¡å±æ§å®å¯æ¢¦",
    "special_features": "brown_color",
    "type": "Flying",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Pidgeotto.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Pidgeot",
    "standardized": "Pidgeot",
    "chinese": "大比鸟",
    "phonetic": "/ˈpɪdʒiət/",
    "phrase": "Pidgeot the bird Pokemon",
    "phraseTranslation": "鸟宝可梦大比鸟",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£é£è¡å±æ§å®å¯æ¢¦",
    "special_features": "brown_color",
    "type": "Flying",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Pidgeot.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Rattata",
    "standardized": "Rattata",
    "chinese": "小拉达",
    "phonetic": "/rəˈtætə/",
    "phrase": "Rattata the mouse Pokemon",
    "phraseTranslation": "鼠宝可梦小拉达",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ®éå±æ§å®å¯æ¢¦",
    "special_features": "purple_color",
    "type": "Normal",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Rattata.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Raticate",
    "standardized": "Raticate",
    "chinese": "拉达",
    "phonetic": "/ˈrætɪkeɪt/",
    "phrase": "Raticate the mouse Pokemon",
    "phraseTranslation": "鼠宝可梦拉达",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ®éå±æ§å®å¯æ¢¦",
    "special_features": "brown_color",
    "type": "Normal",
    "generation": 1,
    "imageURLs": [
      {
        "filename": "Raticate.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f431.svg",
        "type": "Default"
      }
    ]
  },

  // === ç¬¬äºä¸ä»£ (åé½å°åº) ===
  {
    "word": "Chikorita",
    "standardized": "Chikorita",
    "chinese": "菊草叶",
    "phonetic": "/tʃɪkəˈriːtə/",
    "phrase": "Chikorita the leaf Pokemon",
    "phraseTranslation": "叶宝可梦菊草叶",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Chikorita.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Bayleef",
    "standardized": "Bayleef",
    "chinese": "月桂叶",
    "phonetic": "/ˈbeɪliːf/",
    "phrase": "Bayleef the leaf Pokemon",
    "phraseTranslation": "叶宝可梦月桂叶",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Bayleef.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Meganium",
    "standardized": "Meganium",
    "chinese": "大竺葵",
    "phonetic": "/məˈɡeɪniəm/",
    "phrase": "Meganium the herb Pokemon",
    "phraseTranslation": "草宝可梦大竺葵",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Meganium.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Cyndaquil",
    "standardized": "Cyndaquil",
    "chinese": "火球鼠",
    "phonetic": "/ˈsɪndəkwɪl/",
    "phrase": "Cyndaquil the fire mouse Pokemon",
    "phraseTranslation": "火鼠宝可梦火球鼠",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Fire",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Cyndaquil.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Quilava",
    "standardized": "Quilava",
    "chinese": "火岩鼠",
    "phonetic": "/kwɪˈlɑːvə/",
    "phrase": "Quilava the volcano Pokemon",
    "phraseTranslation": "火山宝可梦火岩鼠",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Fire",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Quilava.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Typhlosion",
    "standardized": "Typhlosion",
    "chinese": "火暴兽",
    "phonetic": "/taɪˈfloʊʒən/",
    "phrase": "Typhlosion the volcano Pokemon",
    "phraseTranslation": "火山宝可梦火暴兽",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "yellow_color",
    "type": "Fire",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Typhlosion.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Totodile",
    "standardized": "Totodile",
    "chinese": "小锯鳄",
    "phonetic": "/ˈtoʊtədaɪl/",
    "phrase": "Totodile the big jaw Pokemon",
    "phraseTranslation": "大颚宝可梦小锯鳄",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Totodile.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Croconaw",
    "standardized": "Croconaw",
    "chinese": "蓝鳄",
    "phonetic": "/ˈkroʊkənɔː/",
    "phrase": "Croconaw the big jaw Pokemon",
    "phraseTranslation": "大颚宝可梦蓝鳄",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Croconaw.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Feraligatr",
    "standardized": "Feraligatr",
    "chinese": "大力鳄",
    "phonetic": "/fəˈrælɪɡeɪtər/",
    "phrase": "Feraligatr the big jaw Pokemon",
    "phraseTranslation": "大颚宝可梦大力鳄",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬äºä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 2,
    "imageURLs": [
      {
        "filename": "Feraligatr.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },

  // === ç¬¬ä¸ä¸ä»£ (ä¸°ç¼å°åº) ===
  {
    "word": "Treecko",
    "standardized": "Treecko",
    "chinese": "木守宫",
    "phonetic": "/ˈtriːkoʊ/",
    "phrase": "Treecko the wood gecko Pokemon",
    "phraseTranslation": "木守宫宝可梦木守宫",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Treecko.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Grovyle",
    "standardized": "Grovyle",
    "chinese": "森林蜥蜴",
    "phonetic": "/ˈɡroʊvaɪl/",
    "phrase": "Grovyle the wood gecko Pokemon",
    "phraseTranslation": "木守宫宝可梦森林蜥蜴",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Grovyle.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Sceptile",
    "standardized": "Sceptile",
    "chinese": "蜥蜴王",
    "phonetic": "/ˈseptaɪl/",
    "phrase": "Sceptile the forest Pokemon",
    "phraseTranslation": "森林宝可梦蜥蜴王",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£èå±æ§å®å¯æ¢¦",
    "special_features": "green_color",
    "type": "Grass",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Sceptile.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Torchic",
    "standardized": "Torchic",
    "chinese": "火稚鸡",
    "phonetic": "/ˈtɔːrtʃɪk/",
    "phrase": "Torchic the chick Pokemon",
    "phraseTranslation": "雏鸡宝可梦火稚鸡",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "red_color",
    "type": "Fire",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Torchic.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Combusken",
    "standardized": "Combusken",
    "chinese": "力壮鸡",
    "phonetic": "/kəmˈbʌskən/",
    "phrase": "Combusken the young fowl Pokemon",
    "phraseTranslation": "幼鸟宝可梦力壮鸡",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "red_color",
    "type": "Fire",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Combusken.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Blaziken",
    "standardized": "Blaziken",
    "chinese": "火焰鸡",
    "phonetic": "/ˈbleɪzɪkən/",
    "phrase": "Blaziken the blaze Pokemon",
    "phraseTranslation": "火焰宝可梦火焰鸡",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£ç«å±æ§å®å¯æ¢¦",
    "special_features": "red_color",
    "type": "Fire",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Blaziken.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Mudkip",
    "standardized": "Mudkip",
    "chinese": "水跃鱼",
    "phonetic": "/ˈmʌdkɪp/",
    "phrase": "Mudkip the mud fish Pokemon",
    "phraseTranslation": "泥鱼宝可梦水跃鱼",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Mudkip.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
];

// å»éï¼æ standardized/word ä¿çé¦ä¸ªåºç°ï¼é¿åéå¤è¯æ¡
(function dedupPokemonAllGenerations(){
  try {
    if (!Array.isArray(POKEMON_ALL_GENERATIONS)) return;
    const seen = new Set();
    const newList = [];
        const newList = [];
    "word": "Marshtomp",
    "standardized": "Marshtomp",
    "chinese": "沼跃鱼",
    "phonetic": "/ˈmɑːrʃtɑmp/",
    "phrase": "Marshtomp the mud fish Pokemon",
    "phraseTranslation": "泥鱼宝可梦沼跃鱼",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Marshtomp.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  },
  {
    "word": "Swampert",
    "standardized": "Swampert",
    "chinese": "巨沼怪",
    "phonetic": "/ˈswɑmpərt/",
    "phrase": "Swampert the mud fish Pokemon",
    "phraseTranslation": "泥鱼宝可梦巨沼怪",
    "difficulty": "basic",
    "category": "pokemon",
    "age_group": "3-6",
    "game_source": "Pokemon",
    "character_context": "ç¬¬ä¸ä¸ä»£æ°´å±æ§å®å¯æ¢¦",
    "special_features": "blue_color",
    "type": "Water",
    "generation": 3,
    "imageURLs": [
      {
        "filename": "Swampert.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Default"
      }
    ]
  }
    for (const item of POKEMON_ALL_GENERATIONS) {
      const key = String((item && (item.standardized || item.word)) || '').trim().toLowerCase();
      if (!key) continue;
      if (seen.has(key)) continue;
      seen.add(key);
      newList.push(item);
    }
    POKEMON_ALL_GENERATIONS.length = 0;
    Array.prototype.push.apply(POKEMON_ALL_GENERATIONS, newList);
  } catch (e) {
    if (typeof console !== 'undefined' && console.warn) {
      console.warn('Dedup Pokemon all_generations failed:', e);
    }
  }
})();

// Export vocabulary data
if (typeof module !== 'undefined' && module.exports) {
  module.exports = POKEMON_ALL_GENERATIONS;
} else if (typeof window !== 'undefined') {
  window.POKEMON_ALL_GENERATIONS = POKEMON_ALL_GENERATIONS;
}

// åºäº 52poke ç File:åç¼è§£æåºå¨å½å¾é´ç¼å·ï¼ç»ä¸æ¿æ¢ä¸º PokeAPI å®æ¹ç¨³å®ç´é¾ï¼å¨ä¸ä»£ï¼
(function enhancePokemonImageURLsForAll() {
  try {
    const OFFICIAL_BASE = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/";
    const DREAM_BASE = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/";
    const FILE_RE = /File:(\d{3,4})[^.]*\.(png|jpg|svg)/i;

    function enhance(list) {
      if (!Array.isArray(list)) return;
      list.forEach(item => {
        if (!item || !Array.isArray(item.imageURLs)) return;
        let firstEntry = item.imageURLs[0];
        let firstUrl = firstEntry && typeof firstEntry.url === 'string' ? firstEntry.url : (typeof firstEntry === 'string' ? firstEntry : null);
        let id = null;
        if (firstUrl) {
          const m = firstUrl.match(FILE_RE);
          if (m) id = parseInt(m[1], 10);
        }
        if (!id || isNaN(id)) return;

        newList.push({ filename: `${id}.png`, url: `${OFFICIAL_BASE}${id}.png`, type: "OfficialArtwork" });
        newList.push({ filename: `${id}.svg`, url: `${DREAM_BASE}${id}.svg`, type: "DreamWorld" });

        const seen = new Set(newList.map(x => x.url));
        item.imageURLs.forEach(u => {
          const uObj = (u && typeof u === 'object') ? u : { url: String(u || ""), filename: "", type: "Legacy" };
          if (uObj.url && !seen.has(uObj.url)) {
            newList.push({ filename: uObj.filename || "", url: uObj.url, type: uObj.type || "Legacy" });
            seen.add(uObj.url);
          }
        });
        item.imageURLs = newList;
      });
    }

    enhance(POKEMON_ALL_GENERATIONS);
  } catch (e) {
    if (typeof console !== 'undefined' && console.warn) {
      console.warn('Enhance Pokemon image URLs (all) failed:', e);
    }
  }
})();
