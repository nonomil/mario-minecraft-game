// Auto-merged vocab pack: 游戏专题 / 全部合并
const VOCAB_EXTERNAL_GAME_ALL = [];
