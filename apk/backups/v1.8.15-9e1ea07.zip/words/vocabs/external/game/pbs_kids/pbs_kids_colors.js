// PBS Kids Colors - PBS Kidsé¢è²è¯æ±åº
// åå«PBS Kidsç³»åä¸­çåºç¡é¢è²å­¦ä¹ 
const PBS_KIDS_COLORS = [
  // === åºç¡é¢è² ===
  {
    "word": "Red",
    "standardized": "Red",
    "chinese": "红色",
    "phonetic": "/red/",
    "phrase": "red apple",
    "phraseTranslation": "红苹果",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Red.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f534.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Blue",
    "standardized": "Blue",
    "chinese": "蓝色",
    "phonetic": "/blu/",
    "phrase": "blue sky",
    "phraseTranslation": "蓝天",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Blue.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f535.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Yellow",
    "standardized": "Yellow",
    "chinese": "黄色",
    "phonetic": "/ˈjeloʊ/",
    "phrase": "yellow sun",
    "phraseTranslation": "黄太阳",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Yellow.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e1.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Green",
    "standardized": "Green",
    "chinese": "绿色",
    "phonetic": "/ɡriːn/",
    "phrase": "green grass",
    "phraseTranslation": "绿草",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Green.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e2.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Orange",
    "standardized": "Orange",
    "chinese": "橙色",
    "phonetic": "/ˈɔːrɪndʒ/",
    "phrase": "orange fruit",
    "phraseTranslation": "橙子",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Orange.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e0.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Purple",
    "standardized": "Purple",
    "chinese": "紫色",
    "phonetic": "/ˈpɜːrpəl/",
    "phrase": "purple flower",
    "phraseTranslation": "紫花",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Purple.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e3.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Pink",
    "standardized": "Pink",
    "chinese": "粉色",
    "phonetic": "/pɪŋk/",
    "phrase": "pink flower",
    "phraseTranslation": "粉花",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Pink.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f338.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Brown",
    "standardized": "Brown",
    "chinese": "棕色",
    "phonetic": "/braʊn/",
    "phrase": "brown bear",
    "phraseTranslation": "棕熊",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Brown.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e4.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Black",
    "standardized": "Black",
    "chinese": "黑色",
    "phonetic": "/blæk/",
    "phrase": "black cat",
    "phraseTranslation": "黑猫",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Black.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/26ab.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "White",
    "standardized": "White",
    "chinese": "白色",
    "phonetic": "/waɪt/",
    "phrase": "white snow",
    "phraseTranslation": "白雪",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "White.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/26aa.svg",
        "type": "Emoji"
      }
    ]
  },

  // === æ´å¤é¢è²è¯æ± ===
  {
    "word": "Gray",
    "standardized": "Gray",
    "chinese": "灰色",
    "phonetic": "/ɡreɪ/",
    "phrase": "gray cloud",
    "phraseTranslation": "灰云",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Gray.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/2601.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Silver",
    "standardized": "Silver",
    "chinese": "银色",
    "phonetic": "/ˈsɪlvər/",
    "phrase": "silver coin",
    "phraseTranslation": "银币",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Silver.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Gold",
    "standardized": "Gold",
    "chinese": "金色",
    "phonetic": "/ɡoʊld/",
    "phrase": "gold star",
    "phraseTranslation": "金星",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çåºç¡é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Gold.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/2b50.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Rainbow",
    "standardized": "Rainbow",
    "chinese": "彩虹",
    "phonetic": "/ˈreɪnboʊ/",
    "phrase": "beautiful rainbow",
    "phraseTranslation": "美丽的彩虹",
    "difficulty": "basic",
    "category": "color",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsé¢è²æ¸¸æä¸­çç¹æ®é¢è²",
    "related_activities": ["coloring", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Rainbow.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f308.svg",
        "type": "Emoji"
      }
    ]
  },

  // === å½¢ç¶è¯æ± ===
  {
    "word": "Circle",
    "standardized": "Circle",
    "chinese": "圆形",
    "phonetic": "/ˈsɜːrkəl/",
    "phrase": "round circle",
    "phraseTranslation": "圆圆形",
    "difficulty": "basic",
    "category": "shape",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidså½¢ç¶æ¸¸æä¸­çåºç¡å½¢ç¶",
    "related_activities": ["drawing", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Circle.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e0.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Square",
    "standardized": "Square",
    "chinese": "正方形",
    "phonetic": "/skwer/",
    "phrase": "four square",
    "phraseTranslation": "四正方形",
    "difficulty": "basic",
    "category": "shape",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidså½¢ç¶æ¸¸æä¸­çåºç¡å½¢ç¶",
    "related_activities": ["drawing", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Square.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f7e6.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Triangle",
    "standardized": "Triangle",
    "chinese": "三角形",
    "phonetic": "/ˈtraɪæŋɡəl/",
    "phrase": "three triangle",
    "phraseTranslation": "三三角形",
    "difficulty": "basic",
    "category": "shape",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidså½¢ç¶æ¸¸æä¸­çåºç¡å½¢ç¶",
    "related_activities": ["drawing", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Triangle.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f53a.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Star",
    "standardized": "Star",
    "chinese": "星星",
    "phonetic": "/stɑr/",
    "phrase": "shining star",
    "phraseTranslation": "闪亮的星星",
    "difficulty": "basic",
    "category": "shape",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidså½¢ç¶æ¸¸æä¸­çåºç¡å½¢ç¶",
    "related_activities": ["drawing", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Star.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/2b50.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Heart",
    "standardized": "Heart",
    "chinese": "心形",
    "phonetic": "/hɑrt/",
    "phrase": "red heart",
    "phraseTranslation": "红心形",
    "difficulty": "basic",
    "category": "shape",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidså½¢ç¶æ¸¸æä¸­çåºç¡å½¢ç¶",
    "related_activities": ["drawing", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Heart.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/2764.svg",
        "type": "Emoji"
      }
    ]
  },

  // === æ°å­è¯æ± ===
  {
    "word": "One",
    "standardized": "One",
    "chinese": "一",
    "phonetic": "/wʌn/",
    "phrase": "one apple",
    "phraseTranslation": "一个苹果",
    "difficulty": "basic",
    "category": "number",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsæ°å­æ¸¸æä¸­çåºç¡æ°å­",
    "related_activities": ["counting", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "One.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/31-20e3.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Two",
    "standardized": "Two",
    "chinese": "二",
    "phonetic": "/tu/",
    "phrase": "two birds",
    "phraseTranslation": "两只鸟",
    "difficulty": "basic",
    "category": "number",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsæ°å­æ¸¸æä¸­çåºç¡æ°å­",
    "related_activities": ["counting", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Two.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/32-20e3.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Three",
    "standardized": "Three",
    "chinese": "三",
    "phonetic": "/θri/",
    "phrase": "three cats",
    "phraseTranslation": "三只猫",
    "difficulty": "basic",
    "category": "number",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsæ°å­æ¸¸æä¸­çåºç¡æ°å­",
    "related_activities": ["counting", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Three.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/33-20e3.svg",
        "type": "Emoji"
      }
    ]
  },
  {
];

// Export vocabulary data
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PBS_KIDS_COLORS;
} else if (typeof window !== 'undefined') {
  window.PBS_KIDS_COLORS = PBS_KIDS_COLORS;
}

    "word": "Five",
    "standardized": "Five",
    "chinese": "五",
    "phonetic": "/faɪv/",
    "phrase": "five fingers",
    "phraseTranslation": "五个手指",
    "difficulty": "basic",
    "category": "number",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsæ°å­æ¸¸æä¸­çåºç¡æ°å­",
    "related_activities": ["counting", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Five.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/35-20e3.svg",
        "type": "Emoji"
      }
    ]
  }
    "word": "Four",
    "standardized": "Four",
    "chinese": "四",
    "phonetic": "/fɔːr/",
    "phrase": "four dogs",
    "phraseTranslation": "四只狗",
    "difficulty": "basic",
    "category": "number",
    "age_group": "3-4",
    "game_source": "PBS Kids",
    "character_context": "PBS Kidsæ°å­æ¸¸æä¸­çåºç¡æ°å­",
    "related_activities": ["counting", "matching", "identifying"],
    "imageURLs": [
      {
        "filename": "Four.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/34-20e3.svg",
        "type": "Emoji"
      }
    ]
  },
  {