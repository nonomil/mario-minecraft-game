// Disney Illusion Island Basic Vocabulary - æç®çï¼ä½¿ç¨ Twemoji CDN SVG å¾æ ä½ä¸ºå ä½ï¼
// è¯´æï¼èç¦åä¸»è§ä¸æ ¸å¿ç©ä»¶/å¨ä½ï¼éåä½é¾å¯èã

const DISNEY_ILLUSION_ISLAND_BASIC = [
];

// å¯¼åºï¼å¼å®¹æµè§å¨ä¸ Nodeï¼
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DISNEY_ILLUSION_ISLAND_BASIC;
} else if (typeof window !== 'undefined') {
  window.DISNEY_ILLUSION_ISLAND_BASIC = DISNEY_ILLUSION_ISLAND_BASIC;
}
  // Main Characters
  { word: "Mickey Mouse", chinese: "ç±³èé¼ ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f43a.svg"] },
  { word: "Minnie Mouse", chinese: "ç±³å¦®", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f97a.svg"] },
  { word: "Donald Duck", chinese: "åèé¸­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f986.svg"] },
  { word: "Goofy", chinese: "é«é£", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f61b.svg"] },

  // Friends & NPC
  { word: "Toku", chinese: "æå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d0.svg"] },
  { word: "Hokun", chinese: "éæ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d1.svg"] },

  // Items & World
  { word: "Book of Knowledge", chinese: "ç¥è¯ä¹ä¹¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4d6.svg"] },
  { word: "Map", chinese: "å°å¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f5fa.svg"] },
  { word: "Key", chinese: "é¥å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f5dd.svg"] },
  { word: "Bridge", chinese: "æ¡¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f309.svg"] },
  { word: "Island", chinese: "å°å²", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3dd.svg"] },
  { word: "Temple", chinese: "ç¥åº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26e9.svg"] },
  { word: "Portal", chinese: "ä¼ éé¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f300.svg"] },
  { word: "Magic", chinese: "é­æ³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2728.svg"] },
  { word: "Star", chinese: "ææ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },

  // Actions
  { word: "Jump", chinese: "è·³è·", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3c3.svg"] },
  { word: "Dash", chinese: "å²åº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26a1.svg"] },
  { word: "Swim", chinese: "æ¸¸æ³³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f30a.svg"] },
  { word: "Climb", chinese: "æç¬", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d7.svg"] },
  { word: "Glide", chinese: "æ»ç¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f30d.svg"] },

  // Collectibles
  { word: "Glint", chinese: "éªå/çµå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2728.svg"] },
  { word: "Heart", chinese: "ç±å¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2764.svg"] },
  { word: "Coin", chinese: "éå¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg"] },

  // More Adventure Items
  { word: "Diamond", chinese: "é»ç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f48e.svg"] },
  { word: "Shield", chinese: "ç¾ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6e1.svg"] },
  { word: "Crown", chinese: "çå ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f451.svg"] },
  { word: "Gem", chinese: "å®ç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f48e.svg"] },
  { word: "Tower", chinese: "å¡", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f5fc.svg"] },
  { word: "Castle", chinese: "åå ¡", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3f0.svg"] },
  { word: "Door", chinese: "é¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6aa.svg"] }