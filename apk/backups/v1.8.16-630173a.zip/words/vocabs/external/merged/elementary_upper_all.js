// Auto-merged vocab pack: 小学高年级 / 全部合并
const VOCAB_EXTERNAL_ELEMENTARY_UPPER_ALL = [];
