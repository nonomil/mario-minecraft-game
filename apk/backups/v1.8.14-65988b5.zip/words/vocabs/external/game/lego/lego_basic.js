// LEGO Basic Vocabulary - æç®çï¼ä½¿ç¨ Twemoji CDN SVG å¾æ ä½ä¸ºå ä½ï¼
// è¯´æï¼éç¨éç¨è¡¨æ Emojiï¼é¿åçæä¸è·¨åé®é¢ãURL ç¤ºä¾ï¼https://twemoji.maxcdn.com/v/latest/svg/1f9f1.svg

const LEGO_BASIC = [
];

// å¯¼åºï¼å¼å®¹æµè§å¨ä¸ Nodeï¼
if (typeof module !== 'undefined' && module.exports) {
  module.exports = LEGO_BASIC;
} else if (typeof window !== 'undefined') {
  window.LEGO_BASIC = LEGO_BASIC;
}
  { word: "Brick", chinese: "ä¹é«ç§¯æ¨ç ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f1.svg"] },
  { word: "Minifigure", chinese: "å°äººä»", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d1.svg"] },
  { word: "Car", chinese: "å°æ±½è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f697.svg"] },
  { word: "Train", chinese: "ç«è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f686.svg"] },
  { word: "Boat", chinese: "å°è¹", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26f5.svg"] },
  { word: "Airplane", chinese: "é£æº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2708.svg"] },
  { word: "Helicopter", chinese: "ç´åæº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f681.svg"] },
  { word: "Police Car", chinese: "è­¦è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f693.svg"] },
  { word: "Fire Engine", chinese: "æ¶é²è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f692.svg"] },
  { word: "Ambulance", chinese: "ææ¤è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f691.svg"] },
  { word: "House", chinese: "å°æ¿å­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3e0.svg"] },
  { word: "Door", chinese: "é¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6aa.svg"] },
  { word: "Window", chinese: "çªæ·", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa9f.svg"] },
  { word: "Wheel", chinese: "è½¦è½®", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6de.svg"] },
  { word: "Construction", chinese: "æ½å·¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3d7.svg"] },
  { word: "Tree", chinese: "æ ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f333.svg"] },
  { word: "Flower", chinese: "è±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33c.svg"] },
  { word: "Dog", chinese: "å°ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f436.svg"] },
  { word: "Cat", chinese: "å°ç«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f431.svg"] },
  { word: "Bear", chinese: "å°ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f43b.svg"] },
  { word: "Motorcycle", chinese: "æ©æè½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3cd.svg"] },
  // å¤§è§æ¨¡æ©åï¼+50ï¼è¾¾å°100æ¡ï¼
  { word: "Elephant", chinese: "å¤§è±¡", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f418.svg"] },
  { word: "Giraffe", chinese: "é¿é¢é¹¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f992.svg"] },
  { word: "Zebra", chinese: "æé©¬", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f993.svg"] },
  { word: "Monkey", chinese: "ç´å­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f412.svg"] },
  { word: "Tiger", chinese: "èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f405.svg"] },
  { word: "Bear", chinese: "ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f43b.svg"] },
  { word: "Penguin", chinese: "ä¼é¹", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f427.svg"] },
  { word: "Owl", chinese: "ç«å¤´é¹°", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f989.svg"] },
  { word: "Frog", chinese: "éè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f438.svg"] },
  { word: "Turtle", chinese: "ä¹é¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f422.svg"] },
  { word: "Butterfly", chinese: "è´è¶", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f98b.svg"] },
  { word: "Bee", chinese: "èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41d.svg"] },
  { word: "Ladybug", chinese: "ç¢è«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41e.svg"] },
  { word: "Snail", chinese: "èç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f40c.svg"] },
  { word: "Octopus", chinese: "ç« é±¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f419.svg"] },
  { word: "Whale", chinese: "é²¸é±¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f40b.svg"] },
  { word: "Dolphin", chinese: "æµ·è±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f42c.svg"] },
  { word: "Shark", chinese: "é²¨é±¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f988.svg"] },
  { word: "Crab", chinese: "èè¹", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f980.svg"] },
  { word: "Starfish", chinese: "æµ·æ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },
  { word: "Shell", chinese: "è´å£³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41a.svg"] },
  { word: "Sailboat", chinese: "å¸è¹", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26f5.svg"] },
  { word: "Submarine", chinese: "æ½æ°´è", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6a4.svg"] },
  { word: "Truck", chinese: "å¡è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f69a.svg"] },
  { word: "Fire Truck", chinese: "æ¶é²è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f692.svg"] },
  { word: "Police Car", chinese: "è­¦è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f693.svg"] },
  { word: "Ambulance", chinese: "ææ¤è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f691.svg"] },
  { word: "School Bus", chinese: "æ ¡è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f68c.svg"] },
  { word: "Taxi", chinese: "åºç§è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f695.svg"] },
  { word: "Scooter", chinese: "æ»æ¿è½¦", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6f4.svg"] },
  { word: "Skateboard", chinese: "æ»æ¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6f9.svg"] },
  { word: "Roller Skates", chinese: "æºå°é", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6fc.svg"] },
  { word: "Swing", chinese: "ç§å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a0.svg"] },
  { word: "Slide", chinese: "æ»æ¢¯", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a2.svg"] },
  { word: "Seesaw", chinese: "è··è··æ¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2696.svg"] },
  { word: "Sandbox", chinese: "æ²ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3d6.svg"] },
  { word: "Kite", chinese: "é£ç­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa81.svg"] },
  { word: "Yo-yo", chinese: "æ æ ç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa80.svg"] },
  { word: "Top", chinese: "éèº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3af.svg"] },
  { word: "Puzzle", chinese: "æ¼å¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9e9.svg"] },
  { word: "Blocks", chinese: "ç§¯æ¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f1.svg"] },
  { word: "Doll", chinese: "å¨å¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa86.svg"] },
  { word: "Teddy Bear", chinese: "æ³°è¿ªç", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f8.svg"] },
  { word: "Drum", chinese: "é¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f941.svg"] },
  { word: "Guitar", chinese: "åä»", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3b8.svg"] },
  { word: "Piano", chinese: "é¢ç´", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3b9.svg"] },
  { word: "Trumpet", chinese: "å°å·", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3ba.svg"] },
  { word: "Violin", chinese: "å°æç´", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3bb.svg"] },
  { word: "Microphone", chinese: "éº¦åé£", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a4.svg"] },
  { word: "Camera", chinese: "ç¸æº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4f7.svg"] },
  { word: "Television", chinese: "çµè§", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4fa.svg"] }