# Mario-Minecraft 教育游戏 - 群系系统优化详细计划

> **项目**: mario-minecraft-game (nonomil/mario-minecraft-game)  
> **文档版本**: v2.0  
> **编制日期**: 2026-02-15  
> **适用版本**: V1.3.0+

## 与修复主线关系（必读）

本文件是“群系系统中长期优化蓝图”，用于 Phase 2/3 扩展设计。  
当前版本故障修复请优先执行：

- `./问题分析-实现差距与修复计划-2026-02-16-v2.md`

前置依赖（Gate）：
1. `15-entities-boss.js` 已完成源码与打包接入。
2. `spawnBiomeEnemy()` 已接入主生成/更新/渲染链路。
3. `spawnBiomeDecoration()` 已接入主生成/渲染链路。
4. `settings.villageEnabled` 默认值与设置开关已补齐。

在 Gate 未完成前，本计划中的"新增群系/Boss/复杂机制"不进入开发排期，只作为设计参考。

---

## 📋 目录

1. [执行摘要](#执行摘要)
2. [当前问题分析](#当前问题分析)
3. [优化方案总览](#优化方案总览)
4. [现有群系优化详细设计](#现有群系优化详细设计)
5. [新群系详细设计](#新群系详细设计)
6. [技术实现指南](#技术实现指南)
7. [词汇系统集成方案](#词汇系统集成方案)
8. [开发时间表与里程碑](#开发时间表与里程碑)
9. [测试与验收标准](#测试与验收标准)

---

## 执行摘要

### 项目背景

Mario-Minecraft 是一款创新的教育游戏，将横版跑酷、Minecraft 主题和英语学习结合。当前版本包含 7 个群系，但存在以下核心问题：

- **敌人同质化严重**：前 4 个群系（森林/雪地/沙漠/山地）共享完全相同的敌人池
- **解锁间距不均**：中后期群系间距过大（海洋→地狱 1200 分，地狱→末地 2000 分）
- **机制丰富度不均**：海洋/末地体验优秀，但前期群系机制单薄

### 优化目标

1. **增强群系辨识度**：每个群系至少 50% 专属敌人，独特视觉和玩法机制
2. **平衡内容深度**：新增 5 个群系，将总数扩展到 12 个，解锁间距更均匀
3. **强化教育融合**：群系环境与词汇类别深度关联，提升学习沉浸感
4. **提升玩家留存**：丰富的内容梯度和独特体验，降低中期流失率

### 关键成果

- **现有 7 个群系**：敌人池差异化改造，装饰种类增加 40%+
- **新增 5 个群系**：樱花丛林、蘑菇岛、火山、深暗之域、天空之城
- **词汇系统升级**：9 大词汇类别与群系主题关联
- **预期效果**：玩家平均游戏时长提升 60%+，词汇记忆率提升 35%+

---

## 当前问题分析

### 问题 1：敌人同质化严重 ⚠️

#### 数据分析

| 群系 | 敌人列表 | 独特敌人数 | 共享敌人数 | 独特率 |
|------|---------|-----------|-----------|--------|
| 🌲 森林 | 僵尸、苦力怕、蜘蛛、骷髅、末影人 | 0 | 5 | **0%** |
| ❄️ 雪地 | 僵尸、苦力怕、蜘蛛、骷髅、末影人 | 0 | 5 | **0%** |
| 🏜️ 沙漠 | 僵尸、苦力怕、蜘蛛、骷髅、末影人 | 0 | 5 | **0%** |
| ⛰️ 山地 | 僵尸、苦力怕、蜘蛛、骷髅、末影人 | 0 | 5 | **0%** |
| 🌊 海洋 | 溺尸、河豚、鳕鱼、鱿鱼 | 4 | 0 | **100%** ✅ |
| 🔥 地狱 | 僵尸、猪灵、骷髅、苦力怕、末影人 | 1 | 4 | **20%** |
| 🟣 末地 | 末影螨、潜影贝、末影龙 | 3 | 0 | **100%** ✅ |

#### 玩家影响

- **重复感强**：玩家在前 600 分（森林→沙漠）体验不到战斗差异
- **探索动力不足**：新群系仅视觉变化，缺乏玩法惊喜
- **学习效率低**：敌人名称重复出现，词汇关联性弱

#### 根本原因

- 开发初期使用统一敌人池，缺少群系定制化设计
- 海洋和末地是后期开发，已体现专属设计理念

---

### 问题 2：解锁间距不均 📊

#### 当前分布

```
森林(0) ──200──> 雪地(200) ──200──> 沙漠(400) ──200──> 山地(600)
                                                          ──200──>
海洋(800) ──────────1200──────────> 地狱(2000) ──────────2000──────────> 末地(4000)
   ↑                                    ↑                                    ↑
 正常间距                            突增间距                              突增间距
```

#### 玩家体验问题

| 阶段 | 分数范围 | 平均停留时间 | 问题 |
|------|---------|-------------|------|
| 前期 | 0-800 | 15-20 分钟 | ✅ 节奏良好 |
| 中期 | 800-2000 | **30-40 分钟** | ⚠️ 海洋群系停留过久，容易疲劳 |
| 后期 | 2000-4000 | **40-50 分钟** | ⚠️ 地狱群系停留过久，难度曲线断层 |

#### 流失率数据（预估）

- 海洋阶段流失率：**35%**（停留时间过长）
- 地狱阶段流失率：**28%**（难度突增 + 等待时间长）

---

### 问题 3：机制丰富度不均 🎨

#### 群系机制对比

| 群系 | 独特物理 | 专属敌人 | 特殊机制 | 环境危害 | 丰富度评分 |
|------|---------|---------|---------|---------|-----------|
| 森林 | ❌ | ❌ | ❌ | ❌ | ⭐⭐ |
| 雪地 | ✅ (冰面滑行) | ❌ | ⚠️ (雪堆减速) | ❌ | ⭐⭐⭐ |
| 沙漠 | ❌ | ❌ | ⚠️ (沙尘暴) | ✅ (仙人掌) | ⭐⭐⭐ |
| 山地 | ❌ | ❌ | ✅ (矿石采集) | ✅ (黑暗+岩浆) | ⭐⭐⭐⭐ |
| **海洋** | ✅ (水下物理) | ✅ | ✅ (溺水) | ✅ (溺水) | ⭐⭐⭐⭐⭐ |
| **地狱** | ❌ | ⚠️ | ✅ (热伤害) | ✅ (岩浆+火焰) | ⭐⭐⭐⭐ |
| **末地** | ✅ (低重力) | ✅ | ✅ (传送门) | ✅ (虚空) | ⭐⭐⭐⭐⭐ |

#### 结论

- 海洋、末地是设计标杆，其他群系需向其看齐
- 前期群系过于依赖速度调整，缺乏玩法创新

---

## 优化方案总览

### 分阶段实施路线图

```
Phase 1: 现有群系优化 (4-6 周)
├── 敌人池差异化改造
├── 装饰种类扩展
└── 解锁分数微调

Phase 2: 过渡群系开发 (6-8 周)
├── 樱花丛林 (100 分)
└── 蘑菇岛 (500 分)

Phase 3: 高级群系开发 (8-12 周)
├── 火山 (1200 分)
├── 深暗之域 (3000 分)
└── 天空之城 (5500 分)

Phase 4: 词汇系统集成 (2-3 周)
└── 9 大词汇类别与群系关联
```

### 优化后群系结构

| # | 群系 | 解锁分数 | 新/优化 | 独特率目标 | 核心机制 |
|---|------|---------|---------|-----------|---------|
| 1 | 🌲 森林 | 0 | 优化 | 40% | 天气系统 + 专属敌人 |
| 2 | 🌸 **樱花丛林** | **100** | **新增** | **100%** | **蜂巢召唤 + 花朵奖励** |
| 3 | ❄️ 雪地 | 250 | 优化 | 60% | 冰面滑行 + 专属敌人 |
| 4 | 🏜️ 沙漠 | 450 | 优化 | 60% | 沙尘暴 + 流沙陷阱 |
| 5 | 🍄 **蘑菇岛** | **650** | **新增** | **100%** | **安全区 + 孢子分裂** |
| 6 | ⛰️ 山地 | 900 | 优化 | 60% | 矿石采集 + 洞穴敌人 |
| 7 | 🌊 海洋 | 1200 | 保持 | 100% | 水下物理 ✅ |
| 8 | 🌋 **火山** | **1600** | **新增** | **100%** | **火山喷发 + 温泉回血** |
| 9 | 🔥 地狱 | 2200 | 优化 | 80% | 热伤害 + 远程敌人 |
| 10 | 🌙 **深暗之域** | **3000** | **新增** | **100%** | **噪音系统 + 监守者** |
| 11 | 🟣 末地 | 4000 | 保持 | 100% | 低重力 + Boss ✅ |
| 12 | ☁️ **天空之城** | **5500** | **新增** | **100%** | **极低重力 + 风场** |

---

## 现有群系优化详细设计

### 1. 🌲 森林（Forest）优化方案

#### 当前问题
- 敌人无辨识度（与雪地/沙漠/山地完全相同）
- 装饰虽丰富但缺少互动元素
- 作为起始群系，教学引导不足

#### 优化内容

##### 1.1 敌人池改造

**移除通用敌人**：
- 保留：僵尸 (20HP)、骷髅 (15HP)
- 移除：苦力怕、蜘蛛、末影人 → 分配给其他群系

**新增专属敌人**：

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **女巫 (Witch)** | 26 HP | 8 (药水伤害) | 投掷缓慢/中毒药水，受伤时喝治疗药水 | 药水瓶、荧石粉 | 15% |
| **狼 (Wolf)** | 8 HP | 4 | 群体 AI（攻击 1 只会召唤附近 2-3 只），移动速度 1.3x | 无 | 20% |
| **史莱姆 (Slime)** | 16 HP (大) / 4 HP (小) | 6 / 2 | 击败后分裂成 2-4 个小史莱姆 | 史莱姆球 | 10% |

**保留敌人调整**：
- 僵尸：生成权重 30%（降低）
- 骷髅：生成权重 25%（降低）

**最终敌人池**：女巫、狼、史莱姆、僵尸、骷髅  
**独特率**：3/5 = **60%** ✅

##### 1.2 装饰系统扩展

**新增互动装饰**：

| 装饰 | 生成率 | 互动效果 | 视觉设计 |
|------|--------|---------|---------|
| **苹果树** | 8% | 跳跃撞击树冠掉落苹果（+5 HP） | 橡树 + 红色果实点缀 |
| **蜂巢** | 5% | 攻击后召唤 3 只愤怒蜜蜂（6 秒仇恨） | 挂在树干上的六边形结构 |
| **宝箱** | 2% | 随机掉落：钻石 x3、金苹果、速度药水 | Minecraft 风格木箱 |
| **营火** | 3% | 站立时缓慢回血（+1 HP/秒） | 动画火焰 + 烟雾粒子 |

**保留装饰优化**：
- 树木：增加动画效果（树叶随风摆动）
- 花朵：增加蝴蝶飞舞动画（纯装饰）
- 蘑菇：可收集，回血 +2 HP

##### 1.3 教学引导增强

**新手提示系统**：
- 前 3 次遇到女巫：显示"小心药水攻击！"提示
- 第一次遇到狼群：显示"狼会呼唤同伴！"提示
- 第一次看到苹果树：显示"跳跃撞击树获得食物"

##### 1.4 词汇关联

**重点词汇类别**：自然 (Nature) + 动物 (Animals)

**示例词汇**：
- tree, forest, leaf, branch, flower, mushroom
- wolf, bee, witch, zombie, skeleton
- green, brown, dark, tall, wild

##### 1.5 配置文件更新

```javascript
{
  id: "forest",
  name: "森林",
  unlockScore: 0,
  
  enemyPool: {
    witch: { weight: 0.15, hp: 26, damage: 8 },
    wolf: { weight: 0.20, hp: 8, damage: 4, speedMultiplier: 1.3 },
    slime: { weight: 0.10, hp: 16, damage: 6, splitOnDeath: true },
    zombie: { weight: 0.30, hp: 20, damage: 10 },
    skeleton: { weight: 0.25, hp: 15, damage: 8 }
  },
  
  decorations: {
    apple_tree: { rate: 0.08, interactive: true, effect: "heal_5" },
    beehive: { rate: 0.05, interactive: true, effect: "summon_bees_3" },
    treasure_chest: { rate: 0.02, interactive: true, loot: "random_rare" },
    campfire: { rate: 0.03, interactive: true, effect: "regen_1_per_sec" },
    flower_cluster: { rate: 0.25 },
    mushroom: { rate: 0.10, collectible: true, effect: "heal_2" }
  },
  
  vocabCategory: ["nature", "animals"]
}
```

---

### 2. ❄️ 雪地（Snow）优化方案

#### 当前问题
- 敌人池与森林完全相同（0% 独特率）
- 装饰种类过少（仅 3 种）
- 冰面机制有趣但缺少深度

#### 优化内容

##### 2.1 敌人池改造

**移除通用敌人**：
- 移除：苦力怕、蜘蛛、末影人
- 保留：僵尸、骷髅（作为过渡）

**新增专属敌人**：

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **流浪者 (Stray)** | 20 HP | 6 (箭) + 减速效果 | 射出冰霜箭，命中后减速 50%（3 秒） | 冰霜箭、骨头 | 30% |
| **北极熊 (Polar Bear)** | 30 HP | 15 | 高 HP 近战，移动速度 0.8x，攻击范围 1.5 倍 | 生鱼、皮革 | 20% |
| **冰元素 (Ice Elemental)** | 18 HP | 8 | 死亡时在地面留下冰块（持续 10 秒） | 冰碎片 | 15% |

**最终敌人池**：流浪者、北极熊、冰元素、僵尸、骷髅  
**独特率**：3/5 = **60%** ✅

##### 2.2 装饰系统扩展

**新增装饰**：

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **冰冻湖** | 6% | 完全滑行（摩擦力 0.05），可跨越大距离 | 半透明蓝色冰面 + 裂纹细节 |
| **雪屋 (Igloo)** | 3% | 内部有宝箱（金苹果、保暖药水） | 圆顶白色建筑 + 门洞 |
| **冰雕** | 8% | 纯装饰（企鹅、熊、鱼造型） | 冰块雕刻纹理 |
| **北极光** | 1 个/场景 | 天空特效（绿/蓝色波浪光带） | 半透明渐变带，缓慢移动 |
| **温泉** | 2% | 站立回血 +2 HP/秒（对抗寒冷） | 蒸汽粒子 + 蓝色水面 |

**保留装饰优化**：
- 雪堆：增加滑雪效果（速度 1.5x，3 秒后恢复）
- 冰锥：增加掉落伤害（如果从上方落在上面 +5 伤害）

##### 2.3 环境机制增强

**寒冷系统（可选高级功能）**：
- 每 30 秒失去 1 HP（寒冷伤害）
- 靠近营火/温泉时停止伤害
- 击败北极熊掉落"保暖披风"（抵抗寒冷 60 秒）

##### 2.4 词汇关联

**重点词汇类别**：天气 (Weather) + 自然 (Nature)

**示例词汇**：
- snow, ice, cold, freeze, winter, frost
- bear, penguin, seal, arctic
- white, blue, shiny, slippery, frozen

##### 2.5 解锁分数调整

**原分数**：200  
**新分数**：**250**（与新增樱花丛林拉开间距）

---

### 3. 🏜️ 沙漠（Desert）优化方案

#### 当前问题
- 敌人池仍是基础池（0% 独特率）
- 缺少沙漠标志性建筑（神殿、金字塔）
- 沙尘暴视觉效果好但缺少玩法影响

#### 优化内容

##### 3.1 敌人池改造

**移除通用敌人**：
- 移除：蜘蛛、末影人、僵尸
- 保留：苦力怕、骷髅

**新增专属敌人**：

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **尸壳 (Husk)** | 20 HP | 10 + 饥饿效果 | 攻击施加饥饿（5 秒，禁止回血） | 腐肉、沙子 | 30% |
| **蝎子 (Scorpion)** | 12 HP | 6 + 中毒 | 攻击施加中毒（持续伤害 2 HP/秒，3 秒） | 蝎子尾刺 | 25% |
| **沙尘元素 (Sand Elemental)** | 15 HP | 8 | 沙尘暴中生成，移动速度 1.4x，死亡时爆出沙尘（致盲 2 秒） | 沙之核心 | 10% |

**最终敌人池**：尸壳、蝎子、沙尘元素、苦力怕、骷髅  
**独特率**：3/5 = **60%** ✅

##### 3.2 装饰系统扩展

**新增装饰**：

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **沙漠神殿** | 2% | 内部有宝箱（钻石 x5、金苹果、速度药水）+ 陷阱（TNT 压力板） | 黄色砂岩金字塔，顶部有青色陶瓦 |
| **绿洲** | 3% | 站立回血 +3 HP/秒 + 补充跳跃次数 | 棕榈树 + 蓝色水池 + 草地 |
| **流沙** | 5% | 踩入后缓慢下沉（速度 0.3x，跳跃无效），5 秒后传送回地面 | 黄色沙面 + 向下吸入动画 |
| **骆驼** | 8% | 被动生物，可骑乘（速度 1.5x，持续 15 秒） | Minecraft 风格骆驼模型 |
| **化石** | 4% | 纯装饰（恐龙骨架） | 白色骨骼结构 |

**保留装饰优化**：
- 仙人掌：增加动画（缓慢生长）
- 枯木：有 20% 概率隐藏宝箱

##### 3.3 沙尘暴机制增强

**当前**：仅视觉效果（棕色遮罩）  
**优化后**：
- 沙尘暴期间：视野范围缩小 50%，移动速度 0.7x
- 沙尘元素生成率提升至 30%（平时 10%）
- 玩家可躲进沙漠神殿避难

##### 3.4 词汇关联

**重点词汇类别**：地理 (Geography) + 自然 (Nature)

**示例词汇**：
- desert, sand, dune, oasis, cactus, dry
- scorpion, camel, snake, heat
- yellow, brown, hot, thirsty, ancient

##### 3.5 解锁分数调整

**原分数**：400  
**新分数**：**450**（与雪地拉开间距）

---

### 4. ⛰️ 山地/洞穴（Mountain）优化方案

#### 当前问题
- 矿石系统优秀，但敌人池仍是基础池（0% 独特率）
- 黑暗遮罩好，但缺少照明互动
- 缺少洞穴特色生物

#### 优化内容

##### 4.1 敌人池改造

**移除通用敌人**：
- 移除：苦力怕、末影人
- 保留：僵尸、骷髅、蜘蛛（洞穴主题）

**新增专属敌人**：

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **洞穴蜘蛛 (Cave Spider)** | 12 HP | 4 + 中毒 | 体积小（0.7x），攻击施加中毒（2 HP/秒，5 秒） | 蜘蛛眼、蛛网 | 25% |
| **蝙蝠群 (Bat Swarm)** | 3 HP x 5 | 2 | 群体出现（5 只），快速移动，干扰视线 | 无 | 20% |
| **石像鬼 (Stone Golem)** | 35 HP | 12 | 高护甲（减伤 30%），移动速度 0.6x，只在钻石矿附近生成 | 钻石 x2、石头 | 5% |

**最终敌人池**：洞穴蜘蛛、蝙蝠群、石像鬼、僵尸、骷髅、蜘蛛  
**独特率**：3/6 = **50%** ✅

##### 4.2 装饰系统扩展

**新增装饰**：

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **火把** | 15% | 放置后照亮周围（半径 200px），持续 30 秒 | 木棍 + 火焰粒子 |
| **矿车轨道** | 8% | 装饰，可收集矿车（坐上去加速 1.8x，10 秒） | 铁轨 + 木制矿车 |
| **地下河** | 4% | 水流向右（推动玩家速度 1.3x） | 流动水面 + 蓝色粒子 |
| **蜘蛛网** | 12% | 进入后减速至 0.4x，3 秒后自动破坏 | 白色网状结构 |
| **发光蘑菇** | 10% | 照亮周围 + 可收集（回血 +3 HP） | 蓝/紫色发光蘑菇 |

**保留装饰优化**：
- 矿石：增加闪光效果，采集时播放音效
- 水晶：增加能量波动画

##### 4.3 照明系统增强

**黑暗遮罩动态调整**：
- 基础遮罩：70% 不透明度
- 靠近火把/水晶/岩浆：遮罩淡化至 30%
- 持有火把道具：全场景遮罩减少至 50%

##### 4.4 词汇关联

**重点词汇类别**：地理 (Geography) + 物质 (Materials)

**示例词汇**：
- cave, mountain, rock, stone, crystal, mine
- bat, spider, ore, coal, iron, gold, diamond
- dark, deep, underground, shiny, hard

##### 4.5 解锁分数调整

**原分数**：600  
**新分数**：**900**（为蘑菇岛 650 留出空间）

---

### 5. 🔥 地狱（Nether）优化方案

#### 当前问题
- 仅猪灵是独特敌人（20% 独特率）
- 缺少远程攻击敌人（烈焰人、恶魂）
- 环境危害已足够，需要更具挑战性的敌人

#### 优化内容

##### 5.1 敌人池改造

**移除通用敌人**：
- 移除：僵尸、苦力怕、末影人
- 保留：骷髅、猪灵

**新增专属敌人**：

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **烈焰人 (Blaze)** | 20 HP | 10 (火球) | 远程攻击（火球，着火效果），飞行移动 | 烈焰棒 | 25% |
| **恶魂 (Ghast)** | 10 HP | 15 (大火球) | 超远程攻击（爆炸范围 3x3 格），飞行，移动速度 1.2x | 恶魂之泪 | 15% |
| **凋灵骷髅 (Wither Skeleton)** | 20 HP | 12 + 凋零效果 | 攻击施加凋零（持续伤害 1 HP/秒，8 秒），高伤害 | 凋灵骷髅头颅 | 20% |

**最终敌人池**：烈焰人、恶魂、凋灵骷髅、猪灵、骷髅  
**独特率**：4/5 = **80%** ✅

##### 5.2 装饰系统扩展

**新增装饰**：

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **地狱堡垒** | 2% | 内部有宝箱（下界合金、附魔金苹果）+ 烈焰人刷怪笼 | 深红色地狱砖建筑 |
| **熔岩瀑布（竖向）** | 6% | 从天花板落下，接触 8 伤害 | 橙黄色熔岩流 + 火星粒子 |
| **灵魂火** | 8% | 蓝色火焰，接触 3 伤害 + 减速 50% | 蓝色火焰动画 |
| **哭泣黑曜石** | 4% | 紫色粒子，破坏后获得速度增益 30 秒 | 黑色方块 + 紫色液滴 |

**保留装饰优化**：
- 红蘑菇：生成率提升至 20%（平衡高伤害环境）
- 灵魂沙：增加"陷入"视觉效果（玩家模型下沉）

##### 5.3 词汇关联

**重点词汇类别**：情绪 (Emotions) + 自然 (Nature)

**示例词汇**：
- nether, hell, fire, lava, flame, burn, heat
- blaze, ghast, piglin, skeleton, danger
- red, orange, hot, scary, painful, angry

##### 5.4 解锁分数调整

**原分数**：2000  
**新分数**：**2200**（为火山 1600 和深暗 3000 留出空间）

---

## 新群系详细设计

### 1. 🌸 樱花丛林（Cherry Grove）

#### 设计定位
- **目标玩家**：新手向，休闲探索
- **难度等级**：⭐⭐ (Easy)
- **核心体验**：治愈系视觉 + 蜜蜂互动机制

#### 基础参数

```javascript
{
  id: "cherry_grove",
  name: "樱花丛林",
  color: "#FFB7C5",
  unlockScore: 100,
  
  physics: {
    speedMultiplier: 1.1,      // 微风助力
    gravityMultiplier: 1.0,
    jumpMultiplier: 1.0
  },
  
  groundType: "grass_pink"      // 粉色草地
}
```

#### 视觉设计

##### 天空与光照
- **天空颜色**：粉白渐变 (#FFE4E1 → #FFC0CB → #FFB7C5)
- **环境光**：柔和暖色调（+10% 亮度）
- **粒子系统**：
  - 樱花花瓣（20 个/屏）：粉色，飘落速度 30px/s，左右摆动 ±20px
  - 光斑粒子（10 个/屏）：白色半透明，缓慢上升

##### 地面与平台
- **草地块**：浅绿色基底 + 粉色花纹点缀（10% 区域）
- **平台样式**：木质平台 + 粉色藤蔓装饰

#### 树木系统

| 树种 | 生成率 | 高度 | 树冠 | 特殊效果 |
|------|--------|------|------|---------|
| 樱花树 | 80% | 120-180px | 粉色圆形（R=60px） | 树冠有花瓣飘落动画 |
| 桃树 | 20% | 100-140px | 粉橙色圆形（R=50px） | 有小桃子装饰 |

#### 装饰系统

| 装饰 | 生成率 | 互动效果 | 视觉设计 |
|------|--------|---------|---------|
| **花丛** | 30% | 可收集，双倍分数（+20 分） | 粉/白/紫色混合花簇 |
| **蝴蝶** | 20% | 纯装饰，飞舞动画（8 字形路径） | 彩色蝴蝶精灵 |
| **小溪** | 10% | 装饰，水面反射效果 | 蓝色流水 + 波光粼粼 |
| **兔子** | 15% | 被动生物，可互动获得"兔子之足"（跳跃增强 20 秒） | 白/棕色兔子，跳跃移动 |
| **石桥** | 5% | 跨越小溪的桥梁 | 灰色石拱桥 |
| **花环** | 8% | 可收集，获得"花之祝福"（速度 +20%，30 秒） | 悬挂的粉色花环 |

#### 敌人系统

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **蜜蜂 (Bee)** | 10 HP | 4 + 中毒 | 中立生物，攻击蜂巢后变敌对，3 只同时出现 | 蜂蜜 | 40% |
| **狐狸 (Fox)** | 12 HP | 6 | 会偷取玩家掉落物（击败后取回） | 甜浆果 | 35% |
| **女巫 (Witch)** | 26 HP | 8 | 投掷缓慢/中毒药水 | 药水瓶 | 25% |

**独特率**：3/3 = **100%** ✅

#### 核心机制：蜂巢系统

**蜂巢生成**：
- 生成率：5%
- 位置：挂在树干上（高度 80-120px）
- 视觉：六边形黄色结构 + 动画（蜜蜂进出）

**互动逻辑**：
```javascript
蜂巢状态：
- 未触发：显示 3 只蜜蜂悬浮动画
- 触发后：
  1. 召唤 3 只愤怒蜜蜂（标记为敌对）
  2. 蜜蜂追逐玩家 6 秒（仇恨时间）
  3. 6 秒后变回中立，返回蜂巢
- 冷却时间：30 秒

击败蜜蜂掉落：
- 蜂蜜（回血 +5 HP）
- 蜂蜡（可收集）
```

#### 特殊机制：花朵收集奖励

**规则**：
- 收集 1 朵花：+20 分（普通 +10）
- 收集 5 朵花：触发"花之连击"，30 秒内所有分数 x1.5
- 收集 10 朵花：获得"花之守护"，免疫 1 次伤害

#### 音效设计

| 场景 | 音效 |
|------|------|
| 进入群系 | 轻快的风铃声 + 鸟鸣 |
| 花瓣飘落 | 柔和的风声 |
| 蜜蜂飞舞 | 嗡嗡声（循环） |
| 收集花朵 | 清脆的"叮"声 |
| 攻击蜂巢 | 愤怒蜂鸣（音量增大） |

#### 词汇关联

**重点词汇类别**：自然 (Nature) + 动物 (Animals)

**高频词汇**：
- **植物**：cherry, flower, blossom, petal, tree, grass, pink
- **动物**：bee, fox, rabbit, butterfly, nest
- **形容词**：beautiful, soft, gentle, sweet, colorful
- **动词**：bloom, fly, collect, pollinate

**词汇出现机制**：
- 收集花朵时：显示花朵颜色词汇（pink, purple, white）
- 遇到蜜蜂时：显示 bee, sting, honey
- 看到兔子时：显示 rabbit, hop, cute

#### 教育价值

- **适合年龄**：6-10 岁
- **学习目标**：自然/动物基础词汇，培养观察力
- **认知负荷**：低（温和环境，敌人威胁低）

---

### 2. 🍄 蘑菇岛（Mushroom Island）

#### 设计定位
- **目标玩家**：中级玩家，喜欢探索收集
- **难度等级**：⭐⭐ (Easy)
- **核心体验**：安全区 + 高收集奖励 + 奇幻视觉

#### 基础参数

```javascript
{
  id: "mushroom_island",
  name: "蘑菇岛",
  color: "#DDA0DD",
  unlockScore: 650,
  
  physics: {
    speedMultiplier: 1.0,
    gravityMultiplier: 1.0,
    jumpMultiplier: 1.0
  },
  
  groundType: "mycelium"        // 菌丝块
}
```

#### 视觉设计

##### 天空与光照
- **天空颜色**：紫粉渐变 (#DDA0DD → #BA55D3 → #9370DB)
- **环境光**：柔和紫色调（+5% 亮度）
- **粒子系统**：
  - 孢子粒子（30 个/屏）：紫白色，缓慢上升，轻微旋转
  - 荧光点（15 个/屏）：绿色，闪烁效果

##### 地面与平台
- **菌丝块**：紫灰色基底（#9B9BA7），表面有紫色斑点动画（闪烁）
- **平台样式**：蘑菇茎平台（米色）

#### 树木系统（巨型蘑菇）

| 蘑菇类型 | 生成率 | 高度 | 树冠 | 特殊效果 |
|---------|--------|------|------|---------|
| **巨型红蘑菇** | 50% | 200-300px | 红色伞状（R=100px） | 可站立在树冠上（弹跳平台，弹力 1.3x） |
| **巨型棕蘑菇** | 50% | 180-280px | 棕色伞状（R=90px） | 树冠下方是阴影区（隐藏区域） |

**树冠弹跳机制**：
- 站立在树冠上：自动获得向上弹力（跳跃高度 +30%）
- 可利用弹跳连续跳跃，实现垂直探索

#### 装饰系统

| 装饰 | 生成率 | 互动效果 | 视觉设计 |
|------|--------|---------|---------|
| **小蘑菇（红）** | 20% | 可收集，回血 +3 HP，双倍分数（+20 分） | 红色小蘑菇 |
| **小蘑菇（棕）** | 15% | 可收集，回血 +3 HP，双倍分数（+20 分） | 棕色小蘑菇 |
| **发光蘑菇** | 15% | 照亮周围（R=150px），可收集获得"夜视"（30 秒） | 蓝紫色发光蘑菇 |
| **菌丝地毯** | 20% | 纯装饰，紫色地面覆盖 | 紫色纹理 |
| **蘑菇牛** | 10% | 被动生物，攻击后变敌对（15 HP，10 伤害）| 红色蘑菇背牛 |
| **孢子云** | 8% | 进入后获得"孢子漂浮"（5 秒内重力 0.8x） | 紫色云雾团 |

#### 敌人系统

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **蘑菇牛 (Mooshroom)** | 15 HP | 10 | 被动，攻击后变敌对，只会反击攻击者 | 生牛肉、红蘑菇 | 60% |
| **孢子虫 (Sporeling)** | 8 HP | 4 | 击败后分裂成 2 个小孢子虫（3 HP，2 伤害） | 孢子粉末 | 40% |

**独特率**：2/2 = **100%** ✅

**敌人生成特殊规则**：
- 无主动攻击敌人生成（蘑菇牛是被动）
- 孢子虫只在玩家靠近巨型蘑菇时生成（防御机制）
- 敌人总密度为其他群系的 40%（安全区）

#### 核心机制：分裂系统

**孢子虫分裂逻辑**：
```javascript
击败孢子虫时：
- 播放分裂动画（0.3 秒）
- 生成 2 个小孢子虫：
  - HP: 3
  - 伤害: 2
  - 移动速度: 1.2x（更快）
  - 击败小孢子虫不再分裂

策略价值：
- 优先击败小孢子虫
- 或使用范围攻击同时击败母体和子体
```

#### 特殊机制：蘑菇收集奖励

**规则**：
- 收集 1 个蘑菇：+20 分（普通 +10）
- 收集 10 个蘑菇：触发"孢子爆发"，所有敌人被击退 5 格
- 收集 20 个蘑菇：获得"蘑菇守护"，30 秒内免疫毒伤害

#### 音效设计

| 场景 | 音效 |
|------|------|
| 进入群系 | 神秘的竖琴旋律 + 孢子声（轻柔） |
| 孢子粒子 | 轻微的"噗"声（循环） |
| 收集蘑菇 | 弹性的"咚"声 |
| 孢子虫分裂 | 裂开声 + 液体飞溅声 |
| 蘑菇牛被攻击 | 哞叫声（愤怒） |

#### 词汇关联

**重点词汇类别**：食物 (Food) + 颜色 (Colors)

**高频词汇**：
- **蘑菇相关**：mushroom, spore, fungus, mycelium, cap, stem
- **颜色**：purple, pink, red, brown, blue, glow
- **形容词**：strange, magical, soft, spongy, glowing
- **动词**：grow, spread, collect, split

**词汇出现机制**：
- 收集蘑菇时：显示颜色词汇（red, brown, glowing）
- 孢子虫分裂时：显示 split, divide, multiply
- 看到蘑菇牛时：显示 mushroom, cow, passive

#### 教育价值

- **适合年龄**：8-12 岁
- **学习目标**：颜色/食物词汇，培养分类思维（红蘑菇 vs 棕蘑菇）
- **认知负荷**：低（安全环境，专注收集）

---

### 3. 🌋 火山（Volcano）

#### 设计定位
- **目标玩家**：高级玩家，追求挑战
- **难度等级**：⭐⭐⭐⭐ (Hard)
- **核心体验**：环境危害 + Boss 级敌人 + 风险回报

#### 基础参数

```javascript
{
  id: "volcano",
  name: "火山",
  color: "#FF4500",
  unlockScore: 1600,
  
  physics: {
    speedMultiplier: 0.9,       // 岩浆地形难行
    gravityMultiplier: 1.0,
    jumpMultiplier: 1.0
  },
  
  groundType: "basalt"          // 玄武岩
}
```

#### 视觉设计

##### 天空与光照
- **天空颜色**：橙红渐变 + 烟雾 (#FF4500 → #8B0000 → #4B0000)
- **环境光**：橙红色调（+20% 对比度）
- **粒子系统**：
  - 火山灰（50 个/屏）：灰黑色，上升速度 50px/s
  - 火星粒子（30 个/屏）：橙黄色，快速上升 + 消散
  - 烟雾粒子（20 个/屏）：灰色，缓慢扩散

##### 地面与平台
- **玄武岩块**：深灰色基底（#36454F），表面有橙色裂纹（发光动画）
- **平台样式**：黑曜石平台（黑色，紫色边缘）

#### 装饰系统

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **岩浆裂缝** | 20% | 接触 1 HP/秒伤害 | 地面橙色裂缝 + 热浪扭曲 |
| **火山岩** | 25% | 障碍物，可击碎（3 次攻击） | 黑色不规则岩石 |
| **温泉** | 5% | 站立回血 +5 HP/秒（抵抗热伤害） | 蓝色水池 + 蒸汽粒子 |
| **黑曜石柱** | 15% | 可攀爬，作为高点平台 | 黑色高柱 + 紫色纹路 |
| **岩浆池** | 10% | 接触 5 HP 伤害 + 着火（3 秒，2 HP/秒） | 橙黄色岩浆池 + 气泡动画 |
| **火山口** | 1 个/场景 | 背景装饰，定时喷发（视觉特效） | 远景山峰 + 红光 |

#### 敌人系统

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **岩浆怪 (Magma Cube)** | 25 HP (大) | 8 | 跳跃攻击，击败后分裂成 2-4 个小岩浆怪（8 HP，4 伤害） | 岩浆膏 | 30% |
| **烈焰人 (Blaze)** | 30 HP | 10 | 远程火球攻击（直线轨迹，着火效果），飞行移动 | 烈焰棒 | 35% |
| **火焰精灵 (Fire Spirit)** | 18 HP | 12 | 快速冲刺（1.6x 速度），接触爆炸（5 伤害） | 火焰精华 | 25% |
| **熔岩守卫 (Lava Guardian)** | 60 HP | 20 | 迷你 Boss，只在火山口附近生成，免疫火伤害 | 钻石 x5、火山核心 | 10% |

**独特率**：4/4 = **100%** ✅

#### 核心机制：火山喷发事件

**触发规则**：
- 每 60 秒触发一次
- 玩家在场景中时才触发（避免离线喷发）

**喷发流程**：
```javascript
倒计时阶段（5 秒）：
- 天空变暗（红色闪烁）
- 地面震动效果（屏幕轻微抖动）
- 音效：低沉的隆隆声

喷发阶段（10 秒）：
- 随机 3-5 个位置落下陨石
- 陨石参数：
  - 伤害：15 HP（直接命中）/ 8 HP（范围 2 格内）
  - 视觉：橙红色火球 + 拖尾粒子
  - 落点：砸出岩浆裂缝（持续 15 秒）

玩家应对：
- 观察陨石阴影（提前 2 秒显示落点）
- 躲入温泉区域（免疫喷发伤害）
- 或使用盾牌（减伤 50%）
```

#### 特殊机制：温泉回血点

**设计理念**：高风险环境 + 高价值回血点 = 风险回报平衡

**温泉特性**：
- 生成率：5%（稀有）
- 回血速度：+5 HP/秒
- 安全区：温泉周围 3 格内免疫火山喷发
- 视觉吸引：蓝色光柱（高度 200px）

**策略价值**：
- 玩家需要在环境危害中寻找温泉
- 温泉成为临时安全点（可躲避喷发）
- 鼓励探索而非直接冲关

#### 音效设计

| 场景 | 音效 |
|------|------|
| 进入群系 | 低沉的火山隆隆声（循环） |
| 火山喷发 | 爆炸声 + 岩石碎裂 |
| 陨石落地 | 巨大的撞击声 + 回声 |
| 岩浆怪跳跃 | 黏稠的"咕噜"声 |
| 烈焰人火球 | 呼啸的火焰声 |
| 温泉回血 | 柔和的水声（对比环境） |

#### 词汇关联

**重点词汇类别**：地理 (Geography) + 自然灾害 (Natural Disasters)

**高频词汇**：
- **火山相关**：volcano, lava, magma, eruption, ash, crater
- **岩石**：basalt, obsidian, rock, stone, hot
- **灾害**：danger, explosion, fire, heat, burn
- **形容词**：dangerous, hot, molten, fiery, deadly
- **动词**：erupt, explode, melt, burn, escape

**词汇出现机制**：
- 火山喷发时：eruption, danger, run!
- 陨石落地时：explosion, hot, lava
- 进入温泉时：safe, cool, water
- 击败熔岩守卫时：victory, brave, reward

#### Boss 战设计：熔岩守卫

**生成条件**：
- 玩家靠近火山口（背景）200px 范围内
- 只生成 1 次/场景

**Boss 机制**：
```javascript
熔岩守卫 (60 HP, 20 伤害)：
- 外观：巨型岩浆怪（3x 正常大小）
- 移动：缓慢（0.7x），但跳跃距离 2x
- 攻击模式：
  1. 重击：蓄力 1 秒，砸地（范围 3x3，25 伤害）
  2. 岩浆喷射：向玩家方向喷射 5 个岩浆球
  3. 召唤：召唤 3 只岩浆怪（小）

- 免疫：火伤害、岩浆伤害
- 弱点：水攻击（如果实现）造成 2x 伤害

击败奖励：
- 钻石 x5
- 火山核心（特殊道具，30 秒免疫火伤害）
- 经验 +500 分
```

#### 教育价值

- **适合年龄**：10-14 岁
- **学习目标**：地理/自然灾害词汇，培养应急反应能力
- **认知负荷**：高（需要同时处理敌人 + 环境危害）

---

### 4. 🌙 深暗之域（Deep Dark）

#### 设计定位
- **目标玩家**：核心玩家，追求策略和紧张感
- **难度等级**：⭐⭐⭐⭐⭐ (Extreme)
- **核心体验**：潜行玩法 + 噪音系统 + Boss 威慑

#### 基础参数

```javascript
{
  id: "deep_dark",
  name: "深暗之域",
  color: "#0A0A1A",
  unlockScore: 3000,
  
  physics: {
    speedMultiplier: 0.8,       // 谨慎移动
    gravityMultiplier: 1.0,
    jumpMultiplier: 1.0,
    sneakSpeedMultiplier: 0.5   // 潜行速度
  },
  
  groundType: "sculk"           // 幽匿块
}
```

#### 视觉设计

##### 天空与光照
- **天空颜色**：近乎全黑 (#0A0A1A)，微弱蓝绿光 (#1E3A4A)
- **环境光**：极低（-80% 亮度）
- **视野限制**：仅角色周围 300px 可见（手电筒效果），边缘淡入黑暗
- **粒子系统**：
  - 幽匿脉冲（15 个/屏）：蓝绿色波纹，从感测器发出
  - 暗影粒子（20 个/屏）：深蓝色，缓慢漂浮

##### 地面与平台
- **幽匿块**：深蓝黑色（#0D1821），表面有蓝绿色纹路（动画发光，呼吸效果）
- **平台样式**：幽匿覆盖的石平台

#### 装饰系统

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **幽匿感测器** | 20% | 检测玩家移动（范围 5 格），触发时发出脉冲波 | 蓝绿色方块 + 触角 |
| **幽匿催发体** | 10% | 触发后尖啸（增加噪音值 +30） | 中央有孔洞的方块 + 声波动画 |
| **幽匿脉络** | 25% | 连接感测器和催发体，纯装饰 | 发光的蓝绿色脉络 |
| **古城遗迹柱** | 15% | 障碍物 + 攀爬点 | 深灰色石柱 + 古老纹路 |
| **灵魂灯笼** | 8% | 照亮周围（R=200px），增加视野范围 | 蓝色灯笼 + 火焰粒子 |
| **宝箱（深暗）** | 3% | 包含高级道具（附魔金苹果、钻石 x10），但周围有 2 个感测器 | 黑色宝箱 + 蓝光 |

#### 敌人系统

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **幽匿虫 (Sculk Creeper)** | 5 HP | 3 | 群体出现（3-5 只），快速移动（1.4x） | 幽匿碎片 | 50% |
| **暗影潜行者 (Shadow Stalker)** | 20 HP | 10 | 隐身（50% 透明度），只有移动时可见 | 暗影精华 | 30% |
| **监守者 (Warden)** | 100 HP | 50 | **Boss 级**，噪音达到 100 时召唤，免疫投射物，范围音波攻击 | 监守者之心 | 特殊生成 |

**独特率**：3/3 = **100%** ✅

#### 核心机制：噪音系统

**噪音值机制**：
```javascript
噪音值范围：0-100
- 初始值：0
- 自然衰减：每秒 -2（静止时）

触发噪音的行为：
- 跳跃：+15
- 攻击：+10
- 受伤：+8
- 踩在幽匿感测器上：+20
- 触发幽匿催发体：+30

潜行模式（Shift 键）：
- 移动速度：0.5x
- 跳跃：禁用
- 攻击：+5 噪音（而非 +10）
- 效果：不触发幽匿感测器

噪音等级反馈：
- 0-30：安全（无视觉提示）
- 31-60：警告（屏幕边缘蓝色脉冲）
- 61-90：危险（屏幕震动 + 低沉音效）
- 91-100：召唤监守者！
```

#### Boss 战设计：监守者

**召唤条件**：
- 噪音值达到 100
- 播放召唤动画（5 秒）：地面裂开，监守者从地下爬出

**监守者机制**：
```javascript
监守者 (100 HP, 50 伤害)：
- 外观：巨型人形生物（高 3 格），无眼睛，胸口有发光的"心跳"
- 移动：缓慢（0.6x），但通过声音追踪玩家
- 视觉：完全看不见（无视黑暗），只依赖听觉

攻击模式：
1. 音波冲击：范围攻击（5 格半径，30 伤害），2 秒蓄力
2. 地面猛击：近战（50 伤害），击飞效果
3. 尖啸：召唤 5 只幽匿虫

追踪机制：
- 被噪音吸引（玩家移动、攻击）
- 潜行时无法检测（如果静止）
- 持续 60 秒或被击败

弱点：
- 耐久低（虽然 100 HP，但 Boss 级攻击伤害高）
- 可利用环境障碍物阻挡

击败奖励：
- 监守者之心（特殊道具，30 秒内免疫噪音系统）
- 钻石 x10
- 经验 +800 分

逃脱机制：
- 如果无法击败，玩家可逃到场景边缘
- 监守者 60 秒后自动返回地下
```

#### 特殊机制：潜行挑战

**设计理念**：改变玩法节奏，从"跑酷射击"变为"潜行躲避"

**潜行玩法**：
- **Shift 键激活潜行**：速度 0.5x，禁止跳跃
- **视觉反馈**：角色轮廓变淡（50% 透明度）
- **噪音降低**：移动不触发感测器，攻击噪音减半
- **策略价值**：
  - 安全通过感测器密集区
  - 接近宝箱不触发监守者
  - 躲避暗影潜行者（它们也难以发现潜行玩家）

#### 音效设计

| 场景 | 音效 |
|------|------|
| 进入群系 | 压抑的低频音（40Hz）+ 回声 |
| 幽匿感测器触发 | 清脆的"叮"声 + 脉冲波音效 |
| 噪音值升高 | 心跳声（加速） |
| 监守者召唤 | 低沉的咆哮 + 地面震动 |
| 监守者音波攻击 | 刺耳的音波声 |
| 潜行模式 | 柔和的呼吸声（提示玩家正在潜行） |

#### 词汇关联

**重点词汇类别**：感官 (Senses) + 情绪 (Emotions)

**高频词汇**：
- **感官**：listen, hear, sound, noise, quiet, dark, see, blind
- **情绪**：afraid, scared, careful, nervous, brave, calm
- **动作**：sneak, hide, creep, tiptoe, whisper, silent
- **形容词**：dark, deep, ancient, mysterious, dangerous
- **名词**：warden, darkness, shadow, cave, underground

**词汇出现机制**：
- 噪音值升高时：quiet! careful! listen!
- 触发感测器时：sound, noise, detected
- 监守者出现时：warden, danger, run, hide
- 潜行时：sneak, silent, careful

#### 教育价值

- **适合年龄**：12-16 岁
- **学习目标**：感官/情绪词汇，培养策略思维和自控能力
- **认知负荷**：极高（需要同时管理噪音 + 敌人 + 环境）

---

### 5. ☁️ 天空之城（Sky Dimension）

#### 设计定位
- **目标玩家**：顶级玩家，追求终极挑战
- **难度等级**：⭐⭐⭐⭐⭐ (Extreme)
- **核心体验**：极低重力 + 平台跳跃 + 坠落即死

#### 基础参数

```javascript
{
  id: "sky_dimension",
  name: "天空之城",
  color: "#87CEEB",
  unlockScore: 5500,
  
  physics: {
    speedMultiplier: 1.3,       // 风力加速
    gravityMultiplier: 0.5,     // 极低重力
    jumpMultiplier: 2.0,        // 超级跳跃
    fallDamageMultiplier: 0     // 坠落不造成伤害（因为会直接死亡）
  },
  
  groundType: "cloud"           // 云朵平台
}
```

#### 视觉设计

##### 天空与光照
- **天空颜色**：金色日出渐变 (#87CEEB → #FFD700 → #FF6347)
- **环境光**：明亮温暖（+30% 亮度）
- **粒子系统**：
  - 金色光点（40 个/屏）：闪烁，缓慢上升
  - 彩虹碎片（20 个/屏）：七彩色，旋转飘落
  - 云雾粒子（30 个/屏）：白色半透明，水平漂移

##### 地面与平台
- **云朵平台**：白色半透明（透明度 80%），轻微上下浮动（±10px，周期 3 秒）
- **平台样式**：不规则云朵形状，边缘柔和
- **特殊设计**：无实体地面，坠落到场景底部 = 死亡

#### 树木系统（天空树）

| 树种 | 生成率 | 高度 | 树冠 | 特殊效果 |
|------|--------|------|------|---------|
| **天空橡树** | 60% | 150-200px | 金色圆形（R=70px） | 树冠漂浮（与树干分离 20px）|
| **云杉** | 40% | 120-180px | 白色三角形 | 树冠是云朵材质 |

#### 装饰系统

| 装饰 | 生成率 | 效果 | 视觉设计 |
|------|--------|------|---------|
| **彩虹桥** | 8% | 连接两个平台，可快速通过 | 七彩色拱桥 |
| **星星** | 25% | 可收集，+50 分（高分），收集 5 个触发"连击奖励"（分数 x2，15 秒） | 金色闪烁星星 |
| **天使雕像** | 5% | 纯装饰，标志性建筑 | 白色雕像 + 光环 |
| **浮空岛** | 15% | 小型平台（40x20px），有宝箱/敌人 | 绿色草地岛 + 云雾围绕 |
| **风场** | 10% | 进入后改变跳跃方向（向上/向左/向右） | 蓝色旋风粒子 |
| **云梯** | 12% | 可攀爬的垂直云朵链 | 白色云朵链 |

#### 敌人系统

| 敌人 | HP | 攻击力 | 特殊机制 | 掉落物 | 生成权重 |
|------|-----|--------|---------|--------|---------|
| **幻翼 (Phantom)** | 22 HP | 12 | 飞行敌人，俯冲攻击（1.5x 速度冲刺），击中后飞回天空 | 幻翼膜 | 40% |
| **恼鬼 (Vex)** | 14 HP | 8 | 小型飞行敌人，穿墙（无视平台），群体出现（3 只） | 无 | 35% |
| **天空守卫 (Sky Guardian)** | 35 HP | 15 | 迷你 Boss，飞行 + 投掷能量球（10 伤害） | 钻石 x5、天空之翼 | 15% |
| **云元素 (Cloud Elemental)** | 18 HP | 10 | 击败后变成云朵平台（持续 15 秒） | 云之精华 | 10% |

**独特率**：4/4 = **100%** ✅

#### 核心机制：坠落即死

**设计理念**：高风险高回报，考验平台跳跃技巧

**坠落机制**：
```javascript
场景底部：Y = 屏幕高度 + 200px

玩家坠落判定：
- 如果 player.y > 屏幕高度 + 200px
  → 触发死亡动画（3 秒）
  → 显示"你掉出了天空之城！"
  → 扣除 1 条生命，从最近的云梯重生

视觉反馈：
- 坠落过程：屏幕边缘红色闪烁
- 音效：风声（加速）+ 惊叫声
- 重生时：云雾聚集动画

平衡措施：
- 云梯（重生点）生成率 12%
- 天空守卫掉落"天空之翼"（30 秒内免疫坠落死亡）
- 低重力（0.5x）给予更多空中控制时间
```

#### 核心机制：风场系统

**风场类型**：

| 风场 | 效果 | 视觉 |
|------|------|------|
| **上升风场** | 进入后持续向上推（速度 +100px/s），持续 3 秒 | 蓝色向上箭头粒子 |
| **横向风场（左）** | 水平推动向左（速度 +80px/s），持续 2 秒 | 蓝色向左箭头粒子 |
| **横向风场（右）** | 水平推动向右（速度 +80px/s），持续 2 秒 | 蓝色向右箭头粒子 |

**策略价值**：
- 利用上升风场跳到更高平台
- 横向风场帮助跨越长距离
- 敌人也受风场影响（可利用环境击败敌人）

#### 特殊机制：星星连击系统

**规则**：
```javascript
星星收集：
- 1 星：+50 分
- 2 星：+50 分
- 3 星：+50 分
- 4 星：+50 分
- 5 星：触发"星之连击"
  → 15 秒内所有分数 x2
  → 屏幕边缘金色光效
  → 播放胜利音乐

连击期间：
- 继续收集星星：每个 +100 分（双倍）
- 击败敌人：分数 x2
- 连击结束：显示"连击奖励：+XXX 分"

战略价值：
- 鼓励玩家延迟收集星星（一次性收集 5 个触发连击）
- 在连击期间清理敌人获得更高分数
```

#### Boss 战设计：天空守卫

**生成条件**：
- 随机生成在浮空岛上
- 每个场景最多 2 个

**Boss 机制**：
```javascript
天空守卫 (35 HP, 15 伤害)：
- 外观：金色盔甲骑士，背部有光翼
- 移动：飞行（1.0x 速度），悬浮在空中

攻击模式：
1. 能量球投掷：投掷 3 个能量球（10 伤害，可格挡）
2. 俯冲斩：快速冲向玩家（20 伤害），然后返回
3. 召唤恼鬼：召唤 3 只恼鬼辅助

弱点：
- 投掷能量球时有 1 秒硬直（可反击）
- 被击中时掉落羽毛（可收集回血 +5 HP）

击败奖励：
- 钻石 x5
- 天空之翼（30 秒内免疫坠落死亡）
- 经验 +600 分
```

#### 音效设计

| 场景 | 音效 |
|------|------|
| 进入群系 | 空灵的竖琴旋律 + 风铃声 |
| 风场 | 呼啸的风声 |
| 星星收集 | 清脆的"叮"声（高音） |
| 星之连击触发 | 胜利音乐（15 秒循环） |
| 坠落 | 风声（加速）+ 惊叫声 |
| 幻翼俯冲 | 尖锐的呼啸声 |
| 重生 | 天使合唱（3 秒） |

#### 词汇关联

**重点词汇类别**：天气 (Weather) + 方向 (Directions) + 太空 (Space)

**高频词汇**：
- **天空相关**：sky, cloud, wind, air, fly, float, heaven
- **方向**：up, down, left, right, high, low, above, below
- **天气**：sunny, bright, rainbow, storm, breeze
- **形容词**：light, fluffy, golden, shiny, endless
- **动词**：fly, fall, jump, glide, soar, dive

**词汇出现机制**：
- 进入风场时：up, left, right, wind
- 收集星星时：star, shine, bright, collect
- 坠落时：fall, down, danger, careful
- 星之连击时：amazing, combo, fantastic, great

#### 教育价值

- **适合年龄**：10-16 岁
- **学习目标**：方向/天气词汇，培养空间感知能力
- **认知负荷**：极高（需要精确控制跳跃 + 避开坠落）

---

## 技术实现指南

### 代码结构

#### 1. 群系数据配置文件

**文件路径**：`src/data/biomes.js` 或 `config/biomes.json`

**基础结构**：
```javascript
const BIOMES = {
  forest: {
    id: "forest",
    name: "森林",
    color: "#88CC88",
    unlockScore: 0,
    
    // 物理参数
    physics: {
      speedMultiplier: 1.0,
      gravityMultiplier: 1.0,
      jumpMultiplier: 1.0,
      sneakSpeedMultiplier: 0.5  // 可选（深暗之域）
    },
    
    // 地面类型
    groundType: "grass",  // 对应材质文件
    
    // 背景设置
    background: {
      skyColor: ["#88CC88", "#AADDAA"],  // 渐变色数组
      ambientLight: 1.0,        // 环境光倍率
      parallaxLayers: [         // 视差背景层
        { type: "mountains", speed: 0.2, color: "#336633" },
        { type: "clouds", speed: 0.4, color: "#FFFFFF" }
      ]
    },
    
    // 粒子系统
    particles: {
      leaves: {
        count: 20,
        color: "#66AA66",
        speed: 30,
        sway: 20
      }
    },
    
    // 天气系统
    weather: {
      types: ["clear", "rain", "fog"],
      rainChance: 0.2,
      fogChance: 0.15
    },
    
    // 树木配置
    trees: {
      oak: { rate: 0.50, minHeight: 100, maxHeight: 150, crownRadius: 50 },
      birch: { rate: 0.30, minHeight: 120, maxHeight: 180, crownRadius: 45 },
      darkOak: { rate: 0.20, minHeight: 140, maxHeight: 200, crownRadius: 60 }
    },
    
    // 装饰物配置
    decorations: {
      flower_cluster: { rate: 0.25, collectible: false },
      mushroom: { rate: 0.10, collectible: true, effect: "heal_2" },
      apple_tree: { rate: 0.08, interactive: true, effect: "heal_5" },
      beehive: { rate: 0.05, interactive: true, effect: "summon_bees" }
    },
    
    // 敌人池
    enemies: {
      witch: { 
        weight: 0.15,
        hp: 26,
        damage: 8,
        speed: 1.0,
        attackType: "ranged",
        projectile: "potion",
        drops: ["potion", "glowstone"]
      },
      wolf: {
        weight: 0.20,
        hp: 8,
        damage: 4,
        speed: 1.3,
        attackType: "melee",
        ai: "pack",  // 群体 AI
        packSize: [2, 3]
      },
      slime: {
        weight: 0.10,
        hp: 16,
        damage: 6,
        speed: 0.8,
        attackType: "melee",
        onDeath: "split",  // 分裂机制
        splitCount: [2, 4]
      }
    },
    
    // 词汇类别关联
    vocabCategories: ["nature", "animals"],
    
    // 特殊机制
    specialMechanics: {
      // 自定义机制（如噪音系统、火山喷发）
    }
  },
  
  // 其他群系...
};

export default BIOMES;
```

#### 2. 群系管理器类

**文件路径**：`src/managers/BiomeManager.js`

```javascript
class BiomeManager {
  constructor(game) {
    this.game = game;
    this.currentBiome = null;
    this.biomeData = BIOMES;
    this.transitionDuration = 2000; // 过渡时间（毫秒）
  }
  
  // 根据分数获取当前群系
  getCurrentBiome(score) {
    const sortedBiomes = Object.values(this.biomeData)
      .sort((a, b) => b.unlockScore - a.unlockScore);
    
    for (const biome of sortedBiomes) {
      if (score >= biome.unlockScore) {
        return biome;
      }
    }
    
    return this.biomeData.forest; // 默认返回森林
  }
  
  // 切换群系
  switchBiome(newBiome) {
    if (this.currentBiome?.id === newBiome.id) return;
    
    const oldBiome = this.currentBiome;
    this.currentBiome = newBiome;
    
    // 触发过渡动画
    this.playTransition(oldBiome, newBiome);
    
    // 更新物理参数
    this.applyPhysics(newBiome.physics);
    
    // 切换背景
    this.updateBackground(newBiome.background);
    
    // 初始化粒子系统
    this.initParticles(newBiome.particles);
    
    // 清空旧敌人，生成新敌人
    this.game.enemyManager.clearEnemies();
    this.game.enemyManager.setEnemyPool(newBiome.enemies);
    
    // 显示群系名称提示
    this.showBiomeNotification(newBiome.name);
  }
  
  // 播放过渡动画
  playTransition(oldBiome, newBiome) {
    const canvas = this.game.canvas;
    const ctx = this.game.ctx;
    
    // 屏幕淡出到黑色
    let opacity = 0;
    const fadeOut = setInterval(() => {
      ctx.fillStyle = `rgba(0, 0, 0, ${opacity})`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      opacity += 0.05;
      
      if (opacity >= 1) {
        clearInterval(fadeOut);
        
        // 淡入新群系
        const fadeIn = setInterval(() => {
          opacity -= 0.05;
          ctx.fillStyle = `rgba(0, 0, 0, ${opacity})`;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          if (opacity <= 0) clearInterval(fadeIn);
        }, 50);
      }
    }, 50);
  }
  
  // 应用物理参数
  applyPhysics(physics) {
    this.game.player.speedMultiplier = physics.speedMultiplier;
    this.game.player.gravityMultiplier = physics.gravityMultiplier;
    this.game.player.jumpMultiplier = physics.jumpMultiplier;
    
    if (physics.sneakSpeedMultiplier) {
      this.game.player.sneakSpeedMultiplier = physics.sneakSpeedMultiplier;
    }
  }
  
  // 更新背景
  updateBackground(background) {
    this.game.renderer.setSkyGradient(background.skyColor);
    this.game.renderer.setAmbientLight(background.ambientLight);
    
    if (background.parallaxLayers) {
      this.game.renderer.setParallaxLayers(background.parallaxLayers);
    }
  }
  
  // 初始化粒子系统
  initParticles(particles) {
    this.game.particleManager.clear();
    
    for (const [type, config] of Object.entries(particles)) {
      this.game.particleManager.addParticleType(type, config);
    }
  }
  
  // 显示群系切换提示
  showBiomeNotification(biomeName) {
    const notification = document.createElement('div');
    notification.className = 'biome-notification';
    notification.textContent = `进入 ${biomeName}`;
    document.body.appendChild(notification);
    
    // 动画：淡入 → 停留 → 淡出
    setTimeout(() => notification.classList.add('fade-out'), 2000);
    setTimeout(() => notification.remove(), 3000);
  }
  
  // 每帧更新
  update(deltaTime, score) {
    const targetBiome = this.getCurrentBiome(score);
    
    if (targetBiome.id !== this.currentBiome?.id) {
      this.switchBiome(targetBiome);
    }
    
    // 更新特殊机制（如火山喷发、噪音系统）
    if (this.currentBiome.specialMechanics) {
      this.updateSpecialMechanics(deltaTime);
    }
  }
}

export default BiomeManager;
```

#### 3. 敌人生成管理器

**文件路径**：`src/managers/EnemyManager.js`

```javascript
class EnemyManager {
  constructor(game) {
    this.game = game;
    this.enemies = [];
    this.enemyPool = {};
    this.spawnRate = 2000; // 每 2 秒生成一次
    this.lastSpawnTime = 0;
  }
  
  // 设置当前群系的敌人池
  setEnemyPool(enemyPool) {
    this.enemyPool = enemyPool;
  }
  
  // 生成敌人
  spawn() {
    const now = Date.now();
    if (now - this.lastSpawnTime < this.spawnRate) return;
    
    this.lastSpawnTime = now;
    
    // 根据权重随机选择敌人类型
    const enemyType = this.selectEnemyType();
    if (!enemyType) return;
    
    const config = this.enemyPool[enemyType];
    const enemy = this.createEnemy(enemyType, config);
    
    this.enemies.push(enemy);
  }
  
  // 根据权重随机选择
  selectEnemyType() {
    const totalWeight = Object.values(this.enemyPool)
      .reduce((sum, config) => sum + config.weight, 0);
    
    let random = Math.random() * totalWeight;
    
    for (const [type, config] of Object.entries(this.enemyPool)) {
      random -= config.weight;
      if (random <= 0) return type;
    }
    
    return null;
  }
  
  // 创建敌人实例
  createEnemy(type, config) {
    const x = this.game.canvas.width + 50; // 从屏幕右侧生成
    const y = this.game.groundY - 50;
    
    switch (type) {
      case "witch":
        return new Witch(x, y, config);
      case "wolf":
        return new Wolf(x, y, config);
      case "slime":
        return new Slime(x, y, config);
      // 其他敌人类型...
      default:
        return new Enemy(x, y, config);
    }
  }
  
  // 清空所有敌人
  clearEnemies() {
    this.enemies = [];
  }
  
  // 每帧更新
  update(deltaTime) {
    // 更新所有敌人
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.update(deltaTime);
      
      // 移除屏幕外的敌人
      if (enemy.x < -100 || enemy.isDead) {
        this.enemies.splice(i, 1);
      }
    }
    
    // 生成新敌人
    this.spawn();
  }
  
  // 渲染所有敌人
  render(ctx) {
    for (const enemy of this.enemies) {
      enemy.render(ctx);
    }
  }
}

export default EnemyManager;
```

#### 4. 特殊机制实现示例

##### 噪音系统（深暗之域）

**文件路径**：`src/mechanics/NoiseSystem.js`

```javascript
class NoiseSystem {
  constructor(game) {
    this.game = game;
    this.noiseLevel = 0;
    this.maxNoise = 100;
    this.decayRate = 2; // 每秒衰减
    this.wardenSpawned = false;
  }
  
  // 增加噪音
  addNoise(amount) {
    this.noiseLevel = Math.min(this.noiseLevel + amount, this.maxNoise);
    
    // 触发监守者
    if (this.noiseLevel >= this.maxNoise && !this.wardenSpawned) {
      this.spawnWarden();
    }
    
    // 视觉反馈
    this.updateVisualFeedback();
  }
  
  // 自然衰减
  update(deltaTime) {
    if (this.noiseLevel > 0) {
      this.noiseLevel = Math.max(0, this.noiseLevel - this.decayRate * (deltaTime / 1000));
      this.updateVisualFeedback();
    }
  }
  
  // 监听玩家行为
  onPlayerAction(action) {
    const noiseMap = {
      jump: 15,
      attack: 10,
      hurt: 8,
      sculk_sensor: 20,
      sculk_shrieker: 30
    };
    
    // 潜行模式减半
    const multiplier = this.game.player.isSneaking ? 0.5 : 1.0;
    
    if (noiseMap[action]) {
      this.addNoise(noiseMap[action] * multiplier);
    }
  }
  
  // 召唤监守者
  spawnWarden() {
    this.wardenSpawned = true;
    
    // 播放召唤动画
    this.game.showWarning("监守者正在苏醒...", 5000);
    
    setTimeout(() => {
      const warden = new Warden(
        this.game.player.x + 300,
        this.game.groundY - 150
      );
      this.game.enemyManager.enemies.push(warden);
      
      // 60 秒后如果未击败，监守者返回地下
      setTimeout(() => {
        if (!warden.isDead) {
          warden.burrow(); // 钻回地下动画
        }
        this.wardenSpawned = false;
      }, 60000);
    }, 5000);
  }
  
  // 视觉反馈
  updateVisualFeedback() {
    const level = this.noiseLevel / this.maxNoise;
    
    if (level < 0.3) {
      // 安全：无反馈
      this.game.renderer.setScreenPulse(0);
    } else if (level < 0.6) {
      // 警告：蓝色脉冲
      this.game.renderer.setScreenPulse(0.2, "#00FFFF");
    } else if (level < 0.9) {
      // 危险：屏幕震动
      this.game.renderer.setScreenShake(5);
      this.game.audioManager.playSound("heartbeat");
    } else {
      // 极限：强震动 + 红色脉冲
      this.game.renderer.setScreenShake(10);
      this.game.renderer.setScreenPulse(0.5, "#FF0000");
    }
  }
  
  // 重置噪音
  reset() {
    this.noiseLevel = 0;
    this.wardenSpawned = false;
    this.updateVisualFeedback();
  }
}

export default NoiseSystem;
```

##### 火山喷发系统

**文件路径**：`src/mechanics/VolcanoEruption.js`

```javascript
class VolcanoEruption {
  constructor(game) {
    this.game = game;
    this.interval = 60000; // 每 60 秒喷发
    this.lastEruptionTime = 0;
    this.isErupting = false;
  }
  
  update(deltaTime) {
    const now = Date.now();
    
    // 检查是否需要喷发
    if (now - this.lastEruptionTime >= this.interval && !this.isErupting) {
      this.startEruption();
    }
  }
  
  startEruption() {
    this.isErupting = true;
    this.lastEruptionTime = Date.now();
    
    // 倒计时阶段（5 秒）
    this.game.showWarning("火山即将喷发！", 5000);
    this.game.renderer.setSkyFlash("#FF0000", 5000); // 天空闪红
    this.game.renderer.setScreenShake(3, 5000);
    this.game.audioManager.playSound("volcano_rumble");
    
    setTimeout(() => {
      // 喷发阶段（10 秒）
      this.erupt();
    }, 5000);
  }
  
  erupt() {
    const meteorCount = Math.floor(Math.random() * 3) + 3; // 3-5 个陨石
    
    for (let i = 0; i < meteorCount; i++) {
      setTimeout(() => {
        this.spawnMeteor();
      }, i * 2000); // 每 2 秒落 1 个
    }
    
    // 10 秒后结束喷发
    setTimeout(() => {
      this.isErupting = false;
    }, 10000);
  }
  
  spawnMeteor() {
    const x = Math.random() * this.game.canvas.width;
    const y = -50; // 从屏幕顶部落下
    
    const meteor = {
      x, y,
      targetX: x,
      targetY: this.game.groundY,
      speed: 400, // px/s
      damage: 15,
      splashRadius: 100, // 范围伤害
      
      // 显示阴影（提前 2 秒）
      showShadow: true,
      shadowOpacity: 0.3,
      
      update(deltaTime) {
        this.y += this.speed * (deltaTime / 1000);
        
        // 落地
        if (this.y >= this.targetY) {
          this.impact();
          return true; // 标记为已完成
        }
        return false;
      },
      
      impact() {
        // 播放爆炸动画
        game.particleManager.createExplosion(this.targetX, this.targetY, 30);
        game.audioManager.playSound("meteor_impact");
        
        // 范围伤害
        const dx = game.player.x - this.targetX;
        const dy = game.player.y - this.targetY;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < this.splashRadius) {
          const damage = distance === 0 ? this.damage : Math.floor(this.damage * 0.5);
          game.player.takeDamage(damage);
        }
        
        // 留下岩浆裂缝（持续 15 秒）
        game.hazardManager.createLavaCrack(this.targetX, this.targetY, 15000);
      },
      
      render(ctx) {
        // 绘制阴影
        if (this.showShadow) {
          ctx.fillStyle = `rgba(0, 0, 0, ${this.shadowOpacity})`;
          ctx.beginPath();
          ctx.arc(this.targetX, this.targetY, 30, 0, Math.PI * 2);
          ctx.fill();
        }
        
        // 绘制陨石
        ctx.fillStyle = "#FF4500";
        ctx.beginPath();
        ctx.arc(this.x, this.y, 20, 0, Math.PI * 2);
        ctx.fill();
        
        // 拖尾粒子
        for (let i = 0; i < 5; i++) {
          ctx.fillStyle = `rgba(255, 140, 0, ${0.8 - i * 0.15})`;
          ctx.beginPath();
          ctx.arc(this.x, this.y - i * 10, 15 - i * 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };
    
    this.game.hazards.push(meteor);
  }
}

export default VolcanoEruption;
```

---

## 词汇系统集成方案

### 词汇类别定义

**文件路径**：`words/categories.json`

```json
{
  "nature": {
    "name": "自然",
    "words": [
      { "en": "tree", "cn": "树", "difficulty": 1 },
      { "en": "forest", "cn": "森林", "difficulty": 1 },
      { "en": "leaf", "cn": "叶子", "difficulty": 1 },
      { "en": "flower", "cn": "花", "difficulty": 1 },
      { "en": "mushroom", "cn": "蘑菇", "difficulty": 2 },
      { "en": "volcano", "cn": "火山", "difficulty": 3 }
    ]
  },
  
  "animals": {
    "name": "动物",
    "words": [
      { "en": "wolf", "cn": "狼", "difficulty": 1 },
      { "en": "bee", "cn": "蜜蜂", "difficulty": 1 },
      { "en": "fox", "cn": "狐狸", "difficulty": 1 },
      { "en": "rabbit", "cn": "兔子", "difficulty": 1 },
      { "en": "bear", "cn": "熊", "difficulty": 2 }
    ]
  },
  
  "colors": {
    "name": "颜色",
    "words": [
      { "en": "red", "cn": "红色", "difficulty": 1 },
      { "en": "blue", "cn": "蓝色", "difficulty": 1 },
      { "en": "green", "cn": "绿色", "difficulty": 1 },
      { "en": "yellow", "cn": "黄色", "difficulty": 1 },
      { "en": "purple", "cn": "紫色", "difficulty": 2 },
      { "en": "pink", "cn": "粉色", "difficulty": 2 }
    ]
  },
  
  "weather": {
    "name": "天气",
    "words": [
      { "en": "snow", "cn": "雪", "difficulty": 1 },
      { "en": "rain", "cn": "雨", "difficulty": 1 },
      { "en": "wind", "cn": "风", "difficulty": 1 },
      { "en": "cold", "cn": "冷", "difficulty": 1 },
      { "en": "hot", "cn": "热", "difficulty": 1 }
    ]
  },
  
  "geography": {
    "name": "地理",
    "words": [
      { "en": "desert", "cn": "沙漠", "difficulty": 2 },
      { "en": "mountain", "cn": "山", "difficulty": 1 },
      { "en": "cave", "cn": "洞穴", "difficulty": 2 },
      { "en": "ocean", "cn": "海洋", "difficulty": 2 },
      { "en": "volcano", "cn": "火山", "difficulty": 3 }
    ]
  },
  
  "food": {
    "name": "食物",
    "words": [
      { "en": "apple", "cn": "苹果", "difficulty": 1 },
      { "en": "mushroom", "cn": "蘑菇", "difficulty": 2 },
      { "en": "honey", "cn": "蜂蜜", "difficulty": 2 }
    ]
  },
  
  "emotions": {
    "name": "情绪",
    "words": [
      { "en": "happy", "cn": "快乐", "difficulty": 1 },
      { "en": "afraid", "cn": "害怕", "difficulty": 2 },
      { "en": "careful", "cn": "小心", "difficulty": 2 },
      { "en": "brave", "cn": "勇敢", "difficulty": 2 }
    ]
  },
  
  "senses": {
    "name": "感官",
    "words": [
      { "en": "listen", "cn": "听", "difficulty": 1 },
      { "en": "see", "cn": "看", "difficulty": 1 },
      { "en": "quiet", "cn": "安静", "difficulty": 2 },
      { "en": "dark", "cn": "黑暗", "difficulty": 1 },
      { "en": "sound", "cn": "声音", "difficulty": 2 }
    ]
  },
  
  "materials": {
    "name": "物质",
    "words": [
      { "en": "stone", "cn": "石头", "difficulty": 1 },
      { "en": "iron", "cn": "铁", "difficulty": 2 },
      { "en": "gold", "cn": "金", "difficulty": 2 },
      { "en": "diamond", "cn": "钻石", "difficulty": 3 }
    ]
  }
}
```

### 词汇与群系关联

**文件路径**：`src/data/biomes.js`（扩展）

```javascript
const BIOME_VOCAB_MAPPING = {
  forest: {
    primary: ["nature", "animals"],      // 主要类别
    secondary: ["colors", "food"],       // 次要类别
    weight: { nature: 0.5, animals: 0.3, colors: 0.15, food: 0.05 }
  },
  
  cherry_grove: {
    primary: ["nature", "animals"],
    secondary: ["colors"],
    weight: { nature: 0.4, animals: 0.4, colors: 0.2 }
  },
  
  snow: {
    primary: ["weather", "nature"],
    secondary: ["animals", "colors"],
    weight: { weather: 0.5, nature: 0.3, animals: 0.15, colors: 0.05 }
  },
  
  desert: {
    primary: ["geography", "nature"],
    secondary: ["weather", "animals"],
    weight: { geography: 0.4, nature: 0.3, weather: 0.2, animals: 0.1 }
  },
  
  mushroom_island: {
    primary: ["food", "colors"],
    secondary: ["nature"],
    weight: { food: 0.5, colors: 0.3, nature: 0.2 }
  },
  
  mountain: {
    primary: ["geography", "materials"],
    secondary: ["nature"],
    weight: { geography: 0.4, materials: 0.4, nature: 0.2 }
  },
  
  ocean: {
    primary: ["geography", "animals"],
    secondary: ["colors"],
    weight: { geography: 0.4, animals: 0.4, colors: 0.2 }
  },
  
  volcano: {
    primary: ["geography", "nature"],
    secondary: ["emotions"],
    weight: { geography: 0.5, nature: 0.3, emotions: 0.2 }
  },
  
  nether: {
    primary: ["emotions", "nature"],
    secondary: ["geography"],
    weight: { emotions: 0.4, nature: 0.4, geography: 0.2 }
  },
  
  deep_dark: {
    primary: ["senses", "emotions"],
    secondary: ["geography"],
    weight: { senses: 0.5, emotions: 0.3, geography: 0.2 }
  },
  
  end: {
    primary: ["geography", "emotions"],
    secondary: ["materials"],
    weight: { geography: 0.4, emotions: 0.3, materials: 0.3 }
  },
  
  sky_dimension: {
    primary: ["weather", "geography"],
    secondary: ["emotions"],
    weight: { weather: 0.5, geography: 0.3, emotions: 0.2 }
  }
};
```

### 词汇显示系统

**文件路径**：`src/managers/VocabManager.js`

```javascript
class VocabManager {
  constructor(game) {
    this.game = game;
    this.categories = require('../../words/categories.json');
    this.currentBiomeVocab = [];
    this.displayedWords = new Set(); // 已显示过的单词
    this.wordQueue = []; // 待显示单词队列
  }
  
  // 加载群系词汇
  loadBiomeVocab(biomeId) {
    const mapping = BIOME_VOCAB_MAPPING[biomeId];
    if (!mapping) return;
    
    this.currentBiomeVocab = [];
    
    // 根据权重选择词汇
    for (const [category, weight] of Object.entries(mapping.weight)) {
      const words = this.categories[category].words;
      const count = Math.floor(words.length * weight);
      
      // 随机选择词汇
      const selected = this.shuffleArray(words).slice(0, count);
      this.currentBiomeVocab.push(...selected);
    }
    
    // 打乱顺序
    this.currentBiomeVocab = this.shuffleArray(this.currentBiomeVocab);
  }
  
  // 显示词汇卡片
  showWord(trigger) {
    // 从队列中取出未显示的词汇
    const word = this.getNextWord();
    if (!word) return;
    
    // 记录已显示
    this.displayedWords.add(word.en);
    
    // 创建词汇卡片 UI
    const card = this.createWordCard(word, trigger);
    document.body.appendChild(card);
    
    // 3 秒后自动消失
    setTimeout(() => {
      card.classList.add('fade-out');
      setTimeout(() => card.remove(), 500);
    }, 3000);
    
    // 播放音效
    this.game.audioManager.playSound("word_appear");
    
    // 如果玩家点击正确翻译，获得奖励
    this.setupWordInteraction(card, word);
  }
  
  // 获取下一个词汇
  getNextWord() {
    const unshown = this.currentBiomeVocab.filter(
      w => !this.displayedWords.has(w.en)
    );
    
    if (unshown.length === 0) {
      // 所有词汇已显示，重置
      this.displayedWords.clear();
      return this.currentBiomeVocab[0];
    }
    
    return unshown[0];
  }
  
  // 创建词汇卡片 DOM
  createWordCard(word, trigger) {
    const card = document.createElement('div');
    card.className = 'vocab-card';
    card.innerHTML = `
      <div class="word-trigger">${trigger}</div>
      <div class="word-en">${word.en}</div>
      <div class="word-cn">${word.cn}</div>
      <div class="word-difficulty">★ ${word.difficulty}</div>
    `;
    
    return card;
  }
  
  // 设置词汇互动
  setupWordInteraction(card, word) {
    // 点击卡片翻转显示中文
    card.addEventListener('click', () => {
      card.classList.toggle('flipped');
      
      // 翻到中文后，记录学习进度
      if (card.classList.contains('flipped')) {
        this.recordLearning(word);
        this.game.score += 5; // 学习奖励
      }
    });
  }
  
  // 记录学习进度
  recordLearning(word) {
    // 保存到本地存储
    const learned = JSON.parse(localStorage.getItem('learnedWords') || '[]');
    if (!learned.includes(word.en)) {
      learned.push(word.en);
      localStorage.setItem('learnedWords', JSON.stringify(learned));
    }
  }
  
  // 工具：打乱数组
  shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }
}

export default VocabManager;
```

### 词汇触发时机

**集成到游戏事件**：

```javascript
// 在 src/main.js 中集成

class Game {
  constructor() {
    // ... 其他初始化
    this.vocabManager = new VocabManager(this);
  }
  
  // 收集装饰物时
  onCollectDecoration(decoration) {
    if (decoration.type === 'flower') {
      this.vocabManager.showWord('收集了花朵');
    }
    if (decoration.type === 'mushroom') {
      this.vocabManager.showWord('收集了蘑菇');
    }
  }
  
  // 击败敌人时
  onEnemyDefeated(enemy) {
    this.vocabManager.showWord(`击败了 ${enemy.name}`);
  }
  
  // 进入新群系时
  onBiomeChange(newBiome) {
    this.vocabManager.loadBiomeVocab(newBiome.id);
    this.vocabManager.showWord(`进入 ${newBiome.name}`);
  }
  
  // 触发特殊事件时（火山喷发、监守者召唤）
  onSpecialEvent(eventName) {
    this.vocabManager.showWord(eventName);
  }
}
```

---

## 开发时间表与里程碑

### Phase 1: 现有群系优化 (4-6 周)

#### Week 1-2: 敌人系统重构
- [ ] 重构敌人池配置系统
- [ ] 实现森林专属敌人（女巫、狼、史莱姆）
- [ ] 实现雪地专属敌人（流浪者、北极熊、冰元素）
- [ ] 测试敌人 AI 和平衡性

#### Week 3-4: 装饰系统扩展
- [ ] 森林：苹果树、蜂巢、宝箱、营火
- [ ] 雪地：冰冻湖、雪屋、冰雕、北极光、温泉
- [ ] 沙漠：沙漠神殿、绿洲、流沙、骆驼
- [ ] 山地：火把、矿车轨道、地下河、蜘蛛网

#### Week 5-6: 地狱/末地优化
- [ ] 地狱新增敌人（烈焰人、恶魂、凋灵骷髅）
- [ ] 地狱新增装饰（地狱堡垒、熔岩瀑布）
- [ ] 测试与平衡性调整
- [ ] 内部测试与 Bug 修复

**里程碑 M1**：现有 7 个群系敌人独特率达到 50%+，装饰种类增加 40%+

---

### Phase 2: 过渡群系开发 (6-8 周)

#### Week 7-9: 樱花丛林
- [ ] 实现基础视觉（粉色天空、花瓣粒子）
- [ ] 樱花树/桃树生成系统
- [ ] 专属敌人（蜜蜂、狐狸、女巫）
- [ ] 蜂巢互动系统
- [ ] 花朵收集奖励机制
- [ ] 词汇系统集成
- [ ] 测试与平衡

#### Week 10-12: 蘑菇岛
- [ ] 实现基础视觉（紫色天空、孢子粒子）
- [ ] 巨型蘑菇生成与弹跳机制
- [ ] 专属敌人（蘑菇牛、孢子虫）
- [ ] 分裂系统实现
- [ ] 蘑菇收集奖励机制
- [ ] 安全区敌人生成逻辑
- [ ] 词汇系统集成
- [ ] 测试与平衡

#### Week 13-14: 集成测试
- [ ] 樱花丛林 + 蘑菇岛完整流程测试
- [ ] 群系切换过渡动画验证
- [ ] 解锁分数梯度体验测试
- [ ] 新敌人 AI 与平衡性调整
- [ ] 词汇触发时机与频率验证
- [ ] 内部测试与 Bug 修复

**里程碑 M2**：樱花丛林、蘑菇岛可玩，群系总数达到 9 个

---

### Phase 3: 高级群系开发 (8-12 周)

#### Week 15-18: 火山
- [ ] 实现基础视觉（橙红天空、火山灰粒子、玄武岩地面）
- [ ] 火山远景渲染（锥形火山体 + 火山口发光）
- [ ] 岩浆裂缝 / 岩浆池 / 温泉装饰
- [ ] 专属敌人（岩浆怪、烈焰人、火焰精灵、熔岩守卫）
- [ ] 火山喷发事件系统（倒计时 → 陨石雨 → 岩浆裂缝）
- [ ] 温泉回血点与安全区机制
- [ ] 词汇系统集成
- [ ] 测试与平衡

#### Week 19-22: 深暗之域
- [ ] 实现基础视觉（近全黑环境、幽匿脉冲粒子）
- [ ] 视野限制系统（手电筒效果，径向渐变遮罩）
- [ ] 幽匿感测器 / 幽匿催发体 / 古城遗迹柱 / 灵魂灯笼装饰
- [ ] 专属敌人（幽匿虫、暗影潜行者）
- [ ] 噪音系统实现（噪音值累积 → 视觉反馈 → 召唤监守者）
- [ ] 监守者 Boss 实现（100HP，音波攻击，声音追踪）
- [ ] 潜行模式实现（Shift 键，速度/噪音/感测器交互）
- [ ] 词汇系统集成
- [ ] 测试与平衡

#### Week 23-26: 天空之城
- [ ] 实现基础视觉（金色日出天空、云雾粒子、彩虹碎片）
- [ ] 云朵平台系统（浮动平台、坠落即死判定）
- [ ] 风场系统（上升/横向风场，影响玩家和敌人）
- [ ] 星星收集与连击奖励系统
- [ ] 专属敌人（幻翼、恼鬼、天空守卫、云元素）
- [ ] 彩虹桥 / 浮空岛 / 云梯装饰
- [ ] 词汇系统集成
- [ ] 测试与平衡

**里程碑 M3**：火山、深暗之域、天空之城可玩，群系总数达到 12 个

---

### Phase 4: 词汇系统集成与全局调优 (2-3 周)

#### Week 27-28: 词汇系统深度集成
- [ ] 9 大词汇类别数据完善（nature/animals/colors/weather/geography/food/emotions/senses/materials）
- [ ] 群系-词汇权重映射配置
- [ ] 词汇触发时机集成（收集装饰、击败敌人、进入群系、特殊事件）
- [ ] 词汇卡片 UI 与交互（翻转、学习记录、奖励积分）
- [ ] 学习进度持久化（LocalStorage）

#### Week 29: 全局调优与验收
- [ ] 12 群系完整流程通关测试
- [ ] 解锁分数梯度与难度曲线验证
- [ ] 敌人独特率达标验证（每群系 ≥ 50%）
- [ ] 装饰种类达标验证（每群系 ≥ 5 种）
- [ ] 词汇覆盖率与学习效果验证
- [ ] 性能测试（粒子系统、敌人数量、渲染帧率）
- [ ] 最终 Bug 修复与发布准备

**里程碑 M4**：全部 12 群系 + 词汇系统集成完毕，可发布

---

## 测试与验收标准

### 群系验收标准

| 维度 | 标准 | 验证方法 |
|------|------|---------|
| 敌人独特率 | 每群系 ≥ 50% 专属敌人 | 统计敌人池配置 |
| 装饰种类 | 每群系 ≥ 5 种装饰 | 统计装饰配置 |
| 视觉辨识度 | 截图盲测，正确率 ≥ 90% | 用户测试 |
| 机制差异化 | 每群系至少 1 个独特机制 | 功能清单对照 |
| 词汇关联 | 每群系关联 ≥ 2 个词汇类别 | 配置检查 |
| 性能 | 60fps 稳定，粒子数 ≤ 100/屏 | 帧率监控 |

### 里程碑验收清单

| 里程碑 | 交付物 | 验收条件 |
|--------|--------|---------|
| M1 | 现有 7 群系优化 | 敌人独特率 ≥ 50%，装饰 +40% |
| M2 | 樱花丛林 + 蘑菇岛 | 完整可玩，群系切换流畅 |
| M3 | 火山 + 深暗 + 天空 | 完整可玩，特殊机制正常 |
| M4 | 词汇集成 + 全局调优 | 12 群系通关，词汇系统正常 |

---

*文档版本：v2.0*
*编制日期：2026-02-15*
*最后更新：2026-02-16（清理文档结构，补充 Phase 3/4 时间表与验收标准）*
