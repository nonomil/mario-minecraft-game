# 幼儿园词库

来源：`d:\WorkPlace\Html\单词库\vocabularies\kindergarten\`

包含：
- `kindergarten_1_basic.js`（manifest id: `kindergarten.basic`）
- `kindergarten_2_study.js`（manifest id: `kindergarten.study`）
- `kindergarten_3_nature.js`（manifest id: `kindergarten.nature`）
- `kindergarten_4_communication.js`（manifest id: `kindergarten.communication`）
- `kindergarten_5_daily.js`（manifest id: `kindergarten.daily`）
- `kindergarten_6_general.js`（manifest id: `kindergarten.general`）

字段说明（原始格式）：
- `word`：英文
- `chinese`：中文
- `imageURLs`：图片列表（URL）

