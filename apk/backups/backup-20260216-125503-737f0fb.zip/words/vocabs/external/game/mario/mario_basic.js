// Super Mario Basic Vocabulary - æç®çï¼ä½¿ç¨ Twemoji CDN SVG å¾æ ä½ä¸ºå ä½ï¼
// è¯´æï¼éç¨éç¨è¡¨æ Emojiï¼é¿åçæä¸è·¨åé®é¢ãURL æ ¼å¼ç¤ºä¾ï¼https://twemoji.maxcdn.com/v/latest/svg/1f344.svg

const MARIO_BASIC = [
];

// å¯¼åºï¼å¼å®¹æµè§å¨ä¸ Nodeï¼
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MARIO_BASIC;
} else if (typeof window !== 'undefined') {
  window.MARIO_BASIC = MARIO_BASIC;
}
  { word: "Super Mushroom", chinese: "è¶çº§èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"] },
  { word: "Fire Flower", chinese: "ç«ç°è±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f525.svg"] },
  { word: "Super Star", chinese: "æ æææ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },
  { word: "1-Up", chinese: "ä¸å½å ä¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f340.svg"] },
  { word: "Question Block", chinese: "é®å·ç å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2753.svg"] },
  { word: "Coin", chinese: "éå¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa99.svg"] },
  { word: "Goomba", chinese: "æ å®å®", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f330.svg"] },
  { word: "Koopa Troopa", chinese: "åºå·´åµ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f422.svg"] },
  { word: "Bowser", chinese: "åºå·´", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f409.svg"] },
  { word: "Yoshi", chinese: "èè¥¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f995.svg"] },
  { word: "Princess Peach", chinese: "æ¡è±å¬ä¸»", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f351.svg"] },
  { word: "Toad", chinese: "å¥è¯ºæ¯å¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"] },
  { word: "Pipe", chinese: "æ°´ç®¡", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6aa.svg"] },
  { word: "Flagpole", chinese: "ç»ç¹ææ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f6a9.svg"] },
  { word: "Bullet Bill", chinese: "ç®å¼¹åµ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4a3.svg"] },
  { word: "Mario", chinese: "é©¬éå¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f534.svg"] },
  { word: "Luigi", chinese: "è·¯æå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f7e2.svg"] },
  { word: "Princess Daisy", chinese: "é»è¥¿å¬ä¸»", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f478.svg"] },
  { word: "Rosalina", chinese: "ç½èç³å¨", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },
  { word: "Bowser Jr.", chinese: "é·é¸çJr.", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f476.svg"] },
  { word: "Wario", chinese: "ç¦éå¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f7e1.svg"] },
  { word: "Waluigi", chinese: "ç¦è·¯æå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f7e3.svg"] },
  { word: "Kamek", chinese: "å¡ç¾å", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d9.svg"] },
  { word: "Larry", chinese: "æé", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d1.svg"] },
  { word: "Morton", chinese: "è«é¡¿", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26d4.svg"] },
  { word: "Wendy", chinese: "æ¸©è", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f48e.svg"] },
  { word: "Iggy", chinese: "ä¼å¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9e9.svg"] },
  { word: "Roy", chinese: "ç½ä¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f60e.svg"] },
  { word: "Lemmy", chinese: "è±ç±³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a3.svg"] },
  { word: "Ludwig", chinese: "è·¯å¾·ç»´å¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f399.svg"] },
  { word: "Donkey Kong", chinese: "å¤§éå", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f98d.svg"] },
  { word: "Pauline", chinese: "æ³¢ç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f3a4.svg"] },
  { word: "Birdo", chinese: "èå¤´æª/åµæ³¢", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f95a.svg"] },
  { word: "Piranha Plant", chinese: "é£äººè±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f33f.svg"] },
  { word: "Boo", chinese: "å¸ Boo", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f47b.svg"] },
  { word: "Cheep Cheep", chinese: "åºé±¼/èµ¤é±¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41f.svg"] },
  { word: "Blooper", chinese: "ä¹è´¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f991.svg"] },
  { word: "Hammer Bro", chinese: "éé¤åå¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f528.svg"] },
  { word: "Lakitu", chinese: "äºä¸­å°å­/æå¥åº", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2601.svg"] },
  { word: "Shy Guy", chinese: "å®³ç¾å¹½çµ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f576.svg"] },
  { word: "Dry Bones", chinese: "éª·é«é¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f480.svg"] },
  { word: "Buzzy Beetle", chinese: "ç²å£³è«", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41e.svg"] },
  { word: "Spiny", chinese: "åºé¾", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f1.svg"] },
  { word: "Monty Mole", chinese: "é¼¹é¼ è«è", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f401.svg"] },
  { word: "Thwomp", chinese: "ç³å¤´äºº/ç¢¾åç³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26f0.svg"] },
  { word: "Chain Chomp", chinese: "éçå¬å¬", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26aa.svg"] },
  { word: "Magikoopa", chinese: "é­æ³åºå·´åµ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9d9.svg"] },
  { word: "Green Shell", chinese: "ç»¿é¾å£³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f422.svg"] },
  { word: "Red Shell", chinese: "çº¢é¾å£³", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f422.svg"] },
  { word: "Ice Flower", chinese: "å°è±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2744.svg"] },
  { word: "Super Leaf", chinese: "è¶çº§æ å¶", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f343.svg"] },
  { word: "Tanooki Suit", chinese: "ç¸ç«è£", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f99d.svg"] },
  { word: "Cape Feather", chinese: "æç¯·ç¾½æ¯", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fab6.svg"] },
  { word: "Propeller Mushroom", chinese: "èºææ¡¨èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f32c.svg"] },
  { word: "Mini Mushroom", chinese: "è¿·ä½ èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"] },
  { word: "Mega Mushroom", chinese: "å·¨å¤§èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f344.svg"] },
  { word: "Super Bell", chinese: "è¶çº§éé", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f514.svg"] },
  { word: "Super Acorn", chinese: "è¶çº§æ©¡æ", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f330.svg"] },
  { word: "Boomerang Flower", chinese: "åæéè±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa83.svg"] },
  { word: "Double Cherry", chinese: "ååæ¨±æ¡", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f352.svg"] },
  { word: "Cloud Flower", chinese: "äºæµè±", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2601.svg"] },
  { word: "Rock Mushroom", chinese: "å²©ç³èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/26f0.svg"] },
  { word: "Cape", chinese: "æ«é£", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9e3.svg"] },
  { word: "Star Coin", chinese: "æå¸", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/2b50.svg"] },
  { word: "Fire Mario", chinese: "ç«ç°é©¬éå¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f525.svg"] },
  { word: "Cat Mario", chinese: "ç«ç«é©¬éå¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f431.svg"] },
  { word: "Tanooki Mario", chinese: "ç¸ç«é©¬éå¥¥", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f99d.svg"] },
  { word: "Bee Mushroom", chinese: "èèèè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f41d.svg"] },
  { word: "Spring Mushroom", chinese: "å¼¹ç°§èè", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f9f5.svg"] },
  { word: "Penguin Suit", chinese: "ä¼é¹è£", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f427.svg"] },
  { word: "Boomerang Bro", chinese: "åæéåå¼", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1fa83.svg"] },
  { word: "Koopa Clown Car", chinese: "å°ä¸é£è¹", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f680.svg"] },
  { word: "Super Horn", chinese: "è¶çº§åå­", imageURLs: ["https://twemoji.maxcdn.com/v/latest/svg/1f4e2.svg"] }