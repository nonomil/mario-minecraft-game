// Toca Boca All Games - Toca Bocaå®æ´æ¸¸æè¯æ±åº
// åå«Toca Bocaç³»åä¸­æææ¸¸æçè¯æ±ï¼åºäºå®æ¹èµæº
const TOCA_BOCA_ALL_GAMES = [
  // === Toca Kitchen ç³»å ===
  {
    "word": "Bread",
    "standardized": "Bread",
    "chinese": "面包",
    "phonetic": "/bred/",
    "phrase": "fresh bread",
    "phraseTranslation": "新鲜面包",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["eating", "cooking", "slicing"],
    "imageURLs": [
      {
        "filename": "Bread.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f35e.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Milk",
    "standardized": "Milk",
    "chinese": "牛奶",
    "phonetic": "/mɪlk/",
    "phrase": "white milk",
    "phraseTranslation": "白牛奶",
    "difficulty": "basic",
    "category": "drink",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é¥®å",
    "related_activities": ["drinking", "pouring", "mixing"],
    "imageURLs": [
      {
        "filename": "Milk.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f95b.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Apple",
    "standardized": "Apple",
    "chinese": "苹果",
    "phonetic": "/ˈæpəl/",
    "phrase": "red apple",
    "phraseTranslation": "红苹果",
    "difficulty": "basic",
    "category": "fruit",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çæ°´æ",
    "related_activities": ["eating", "cutting", "peeling"],
    "imageURLs": [
      {
        "filename": "Apple.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f34e.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Banana",
    "standardized": "Banana",
    "chinese": "香蕉",
    "phonetic": "/bəˈnænə/",
    "phrase": "yellow banana",
    "phraseTranslation": "黄香蕉",
    "difficulty": "basic",
    "category": "fruit",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çæ°´æ",
    "related_activities": ["eating", "peeling", "mashing"],
    "imageURLs": [
      {
        "filename": "Banana.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f34c.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Carrot",
    "standardized": "Carrot",
    "chinese": "胡萝卜",
    "phonetic": "/ˈkærət/",
    "phrase": "orange carrot",
    "phraseTranslation": "橙胡萝卜",
    "difficulty": "basic",
    "category": "vegetable",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çè¬è",
    "related_activities": ["eating", "cutting", "cooking"],
    "imageURLs": [
      {
        "filename": "Carrot.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f955.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Cheese",
    "standardized": "Cheese",
    "chinese": "奶酪",
    "phonetic": "/tʃiːz/",
    "phrase": "yellow cheese",
    "phraseTranslation": "黄奶酪",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["eating", "cooking", "slicing"],
    "imageURLs": [
      {
        "filename": "Cheese.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f9c0.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Egg",
    "standardized": "Egg",
    "chinese": "鸡蛋",
    "phonetic": "/eɡ/",
    "phrase": "white egg",
    "phraseTranslation": "白鸡蛋",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["eating", "cooking", "cracking"],
    "imageURLs": [
      {
        "filename": "Egg.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f95a.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Butter",
    "standardized": "Butter",
    "chinese": "黄油",
    "phonetic": "/ˈbʌtər/",
    "phrase": "soft butter",
    "phraseTranslation": "软黄油",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["spreading", "cooking", "melting"],
    "imageURLs": [
      {
        "filename": "Butter.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f9c8.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Sugar",
    "standardized": "Sugar",
    "chinese": "糖",
    "phonetic": "/ˈʃʊɡər/",
    "phrase": "white sugar",
    "phraseTranslation": "白糖",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["sweetening", "mixing", "baking"],
    "imageURLs": [
      {
        "filename": "Sugar.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f9c9.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Salt",
    "standardized": "Salt",
    "chinese": "盐",
    "phonetic": "/sɔːlt/",
    "phrase": "white salt",
    "phraseTranslation": "白盐",
    "difficulty": "basic",
    "category": "food",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Kitchenä¸­çåºç¡é£ç©",
    "related_activities": ["seasoning", "mixing", "cooking"],
    "imageURLs": [
      {
        "filename": "Salt.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f9c2.svg",
        "type": "Emoji"
      }
    ]
  },

  // === Toca Pet Doctor ç³»å ===
  {
    "word": "Cat",
    "standardized": "Cat",
    "chinese": "猫",
    "phonetic": "/kæt/",
    "phrase": "cute cat",
    "phraseTranslation": "可爱的猫",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "playing"],
    "imageURLs": [
      {
        "filename": "Cat.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f431.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Dog",
    "standardized": "Dog",
    "chinese": "狗",
    "phonetic": "/dɔːɡ/",
    "phrase": "happy dog",
    "phraseTranslation": "快乐的狗",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "playing"],
    "imageURLs": [
      {
        "filename": "Dog.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f436.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Rabbit",
    "standardized": "Rabbit",
    "chinese": "兔子",
    "phonetic": "/ˈræbɪt/",
    "phrase": "soft rabbit",
    "phraseTranslation": "柔软的兔子",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "playing"],
    "imageURLs": [
      {
        "filename": "Rabbit.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f407.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Bird",
    "standardized": "Bird",
    "chinese": "鸟",
    "phonetic": "/bɜːrd/",
    "phrase": "colorful bird",
    "phraseTranslation": "彩色的鸟",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "playing"],
    "imageURLs": [
      {
        "filename": "Bird.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f426.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Hamster",
    "standardized": "Hamster",
    "chinese": "仓鼠",
    "phonetic": "/ˈhæmstər/",
    "phrase": "small hamster",
    "phraseTranslation": "小仓鼠",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "playing"],
    "imageURLs": [
      {
        "filename": "Hamster.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f439.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Fish",
    "standardized": "Fish",
    "chinese": "鱼",
    "phonetic": "/fɪʃ/",
    "phrase": "swimming fish",
    "phraseTranslation": "游泳的鱼",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "watching"],
    "imageURLs": [
      {
        "filename": "Fish.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f41f.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Turtle",
    "standardized": "Turtle",
    "chinese": "乌龟",
    "phonetic": "/ˈtɜːrtəl/",
    "phrase": "slow turtle",
    "phraseTranslation": "慢乌龟",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "watching"],
    "imageURLs": [
      {
        "filename": "Turtle.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f422.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Lizard",
    "standardized": "Lizard",
    "chinese": "蜥蜴",
    "phonetic": "/ˈlɪzərd/",
    "phrase": "green lizard",
    "phraseTranslation": "绿蜥蜴",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "watching"],
    "imageURLs": [
      {
        "filename": "Lizard.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f98e.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Snake",
    "standardized": "Snake",
    "chinese": "蛇",
    "phonetic": "/sneɪk/",
    "phrase": "long snake",
    "phraseTranslation": "长蛇",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "watching"],
    "imageURLs": [
      {
        "filename": "Snake.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f40d.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Frog",
    "standardized": "Frog",
    "chinese": "青蛙",
    "phonetic": "/frɔːɡ/",
    "phrase": "green frog",
    "phraseTranslation": "绿青蛙",
    "difficulty": "basic",
    "category": "animal",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Pet Doctorä¸­çå® ç©",
    "related_activities": ["caring", "feeding", "watching"],
    "imageURLs": [
      {
        "filename": "Frog.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f438.svg",
        "type": "Emoji"
      }
    ]
  },

  // === Toca Builders ç³»å ===
  {
    "word": "House",
    "standardized": "House",
    "chinese": "房子",
    "phonetic": "/haʊs/",
    "phrase": "big house",
    "phraseTranslation": "大房子",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "constructing", "playing"],
    "imageURLs": [
      {
        "filename": "House.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f3e0.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Chair",
    "standardized": "Chair",
    "chinese": "椅子",
    "phonetic": "/tʃer/",
    "phrase": "wooden chair",
    "phraseTranslation": "木椅子",
    "difficulty": "basic",
    "category": "furniture",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå®¶å·",
    "related_activities": ["building", "sitting", "playing"],
    "imageURLs": [
      {
        "filename": "Chair.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1fa91.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Table",
    "standardized": "Table",
    "chinese": "桌子",
    "phonetic": "/ˈteɪbəl/",
    "phrase": "dining table",
    "phraseTranslation": "餐桌",
    "difficulty": "basic",
    "category": "furniture",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå®¶å·",
    "related_activities": ["building", "eating", "playing"],
    "imageURLs": [
      {
        "filename": "Table.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f4ba.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Bed",
    "standardized": "Bed",
    "chinese": "床",
    "phonetic": "/bed/",
    "phrase": "comfortable bed",
    "phraseTranslation": "舒适的床",
    "difficulty": "basic",
    "category": "furniture",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå®¶å·",
    "related_activities": ["building", "sleeping", "playing"],
    "imageURLs": [
      {
        "filename": "Bed.png",
        "url": "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/1f6cf.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Door",
    "standardized": "Door",
    "chinese": "门",
    "phonetic": "/dɔːr/",
    "phrase": "wooden door",
    "phraseTranslation": "木门",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "opening", "playing"],
    "imageURLs": [
      {
        "filename": "Door.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f6aa.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Window",
    "standardized": "Window",
    "chinese": "窗户",
    "phonetic": "/ˈwɪndoʊ/",
    "phrase": "big window",
    "phraseTranslation": "大窗户",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "looking", "playing"],
    "imageURLs": [
      {
        "filename": "Window.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1fa9f.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Wall",
    "standardized": "Wall",
    "chinese": "墙",
    "phonetic": "/wɔːl/",
    "phrase": "strong wall",
    "phraseTranslation": "坚固的墙",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "constructing", "playing"],
    "imageURLs": [
      {
        "filename": "Wall.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1faa7.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Roof",
    "standardized": "Roof",
    "chinese": "屋顶",
    "phonetic": "/ruːf/",
    "phrase": "red roof",
    "phraseTranslation": "红屋顶",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "constructing", "playing"],
    "imageURLs": [
      {
        "filename": "Roof.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3d8.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Floor",
    "standardized": "Floor",
    "chinese": "地板",
    "phonetic": "/flɔːr/",
    "phrase": "wooden floor",
    "phraseTranslation": "木地板",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "walking", "playing"],
    "imageURLs": [
      {
        "filename": "Floor.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f6bf.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Stairs",
    "standardized": "Stairs",
    "chinese": "楼梯",
    "phonetic": "/sterz/",
    "phrase": "wooden stairs",
    "phraseTranslation": "木楼梯",
    "difficulty": "basic",
    "category": "building",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Buildersä¸­çå»ºç­",
    "related_activities": ["building", "climbing", "playing"],
    "imageURLs": [
      {
        "filename": "Stairs.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ae.svg",
        "type": "Emoji"
      }
    ]
  },

  // === Toca Life ç³»å ===
  {
    "word": "Family",
    "standardized": "Family",
    "chinese": "家庭",
    "phonetic": "/ˈfæməli/",
    "phrase": "happy family",
    "phraseTranslation": "快乐的家庭",
    "difficulty": "basic",
    "category": "life",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­ççæ´»æ¦å¿µ",
    "related_activities": ["playing", "caring", "loving"],
    "imageURLs": [
      {
        "filename": "Family.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f46a.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Friend",
    "standardized": "Friend",
    "chinese": "朋友",
    "phonetic": "/frend/",
    "phrase": "good friend",
    "phraseTranslation": "好朋友",
    "difficulty": "basic",
    "category": "life",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­ççæ´»æ¦å¿µ",
    "related_activities": ["playing", "sharing", "caring"],
    "imageURLs": [
      {
        "filename": "Friend.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f46c.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "School",
    "standardized": "School",
    "chinese": "学校",
    "phonetic": "/skuːl/",
    "phrase": "big school",
    "phraseTranslation": "大学校",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["learning", "playing", "studying"],
    "imageURLs": [
      {
        "filename": "School.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3eb.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Park",
    "standardized": "Park",
    "chinese": "公园",
    "phonetic": "/pɑːrk/",
    "phrase": "beautiful park",
    "phraseTranslation": "美丽的公园",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["playing", "running", "enjoying"],
    "imageURLs": [
      {
        "filename": "Park.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3de.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Hospital",
    "standardized": "Hospital",
    "chinese": "医院",
    "phonetic": "/ˈhɑːspɪtəl/",
    "phrase": "white hospital",
    "phraseTranslation": "白医院",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["caring", "helping", "healing"],
    "imageURLs": [
      {
        "filename": "Hospital.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3e5.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Store",
    "standardized": "Store",
    "chinese": "商店",
    "phonetic": "/stɔːr/",
    "phrase": "big store",
    "phraseTranslation": "大商店",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["shopping", "buying", "selling"],
    "imageURLs": [
      {
        "filename": "Store.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3ea.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Restaurant",
    "standardized": "Restaurant",
    "chinese": "餐厅",
    "phonetic": "/ˈrestərɑːnt/",
    "phrase": "nice restaurant",
    "phraseTranslation": "好餐厅",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["eating", "cooking", "serving"],
    "imageURLs": [
      {
        "filename": "Restaurant.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f374.svg",
        "type": "Emoji"
      }
    ]
  },
  {
    "word": "Beach",
    "standardized": "Beach",
    "chinese": "海滩",
    "phonetic": "/biːtʃ/",
    "phrase": "sandy beach",
    "phraseTranslation": "沙滩",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["playing", "swimming", "building"],
    "imageURLs": [
      {
        "filename": "Beach.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f3d6.svg",
        "type": "Emoji"
      }
    ]
  },
  {
];

// Export vocabulary data
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TOCA_BOCA_ALL_GAMES;
} else if (typeof window !== 'undefined') {
  window.TOCA_BOCA_ALL_GAMES = TOCA_BOCA_ALL_GAMES;
}

    "word": "Forest",
    "standardized": "Forest",
    "chinese": "森林",
    "phonetic": "/ˈfɔːrɪst/",
    "phrase": "green forest",
    "phraseTranslation": "绿森林",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["exploring", "hiking", "discovering"],
    "imageURLs": [
      {
        "filename": "Forest.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/1f332.svg",
        "type": "Emoji"
      }
    ]
  }
    "word": "Mountain",
    "standardized": "Mountain",
    "chinese": "山",
    "phonetic": "/ˈmaʊntən/",
    "phrase": "big mountain",
    "phraseTranslation": "大山",
    "difficulty": "basic",
    "category": "place",
    "age_group": "3-4",
    "game_source": "Toca Boca",
    "character_context": "Toca Lifeä¸­çå°ç¹",
    "related_activities": ["climbing", "exploring", "hiking"],
    "imageURLs": [
      {
        "filename": "Mountain.png",
        "url": "https://twemoji.maxcdn.com/v/latest/svg/26f0.svg",
        "type": "Emoji"
      }
    ]
  },
  {